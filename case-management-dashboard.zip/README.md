# Case Management Dashboard

A local, Excel-backed dashboard for tracking employee workplace concerns. It is designed for HR, employee relations, and compliance teams that need to create, review, filter, group, and summarize sensitive case records without sending data to an outside service.

## Run It

1. Keep the entire project folder together.
2. Double-click `index.html`.
3. The dashboard opens with a blank workbook snapshot containing the required headers and issue categories.
4. Click **Import Excel** and choose `excel\cases.xlsx` to work with the supplied workbook.

There is no server, command file, package installation, or terminal step required.

## Excel-Only Saving

The Excel workbook is the persistence format. The dashboard does not use `localStorage`, `sessionStorage`, IndexedDB, cookies, or another browser data store for case data.

After **Import Excel**:

- In supported Chrome and Edge versions, the selected workbook remains attached for the current page session. Case edits, follow-up changes, grouping changes, reopen/close actions, and other data changes are saved back to that workbook automatically.
- Click **Save to Excel** at any time to save manually.
- In browsers that cannot write directly to a selected file, **Save to Excel** downloads an updated `.xlsx` copy. Replace the workbook in the `excel` folder with that copy when needed.
- **Export Excel** always downloads a separate `.xlsx` copy.

For security reasons, a directly opened `index.html` cannot silently read a neighboring Excel file. Use **Import Excel** once per page session to select the workbook. The file permission is held in memory only while the page is open; it is not stored in the browser.

The save status beside the case table shows whether a workbook is selected, whether changes are unsaved, or whether a save completed.

## Dashboard Features

- Create, view, edit, search, and filter cases.
- Delete a selected case after a confirmation prompt. Its follow-up entries are removed with it.
- Separate **Open Cases**, **Closed Cases**, and **All Cases** tabs.
- Open a closed case and use **Reopen Case** when work resumes.
- Track multiple follow-up dates and notes per case.
- Link cases involving the same accused employee during the same general period.
- Review linked-case details and possible matching cases.
- View metrics, aging, follow-up health, issue mix, status mix, and monthly graphs.
- Generate a rule-based executive summary without AI.
- Generate a factual, rule-based narrative for each selected case without AI.
- Use Privacy Mode to abbreviate names and mask employee IDs while reviewing records.

## Case Fields

Each case can include:

- Date collected
- Reporting employee name and employee ID
- Employee manager
- Issue or concern category
- Accused employee
- Investigation URL
- Case summary
- Sensitivity level
- Case status
- Linked concern group details
- Multiple follow-up dates and notes

The investigation URL is displayed using the reporting employee's name when privacy mode is off. The dashboard rejects unsafe URL schemes such as `javascript:`.

## Case Tabs And Filters

Use the case tabs to switch between open, closed, and all records. The table supports sorting by Case ID, date, employee, manager, issue, linked group, accused employee, and follow-up status.

Filters include:

- Search text
- Issue category
- Manager
- Accused employee
- Follow-up status
- Linked concern group
- Date collected range

## Linked Concern Groups

Grouping is for cases where two or more reporting employees are talking about the same accused employee during the same general period.

For example, two reporting employees can be linked when they name the same accused employee during the same general period. Both cases can then be tracked together without treating them as one report.

A group does not mean the reports have the same outcome. It only connects records that may describe the same underlying period or subject. The dashboard may suggest possible matches, but the user decides whether to link them.

## Metrics And Graphs

The **Metrics** tab includes:

- Total, open, and closed case counts
- Cases needing follow-up
- High-sensitivity open cases
- Average open-case age
- New cases in the last 30 days
- Linked group count and potential matches
- Closure rate and follow-up health
- Issue category mix
- Linked group status
- Oldest open cases

Graphs show cases by month, status mix, and top issue types. Metric cards include contributing case IDs when records exist so totals can be traced back to records.

## Workbook Format

The supplied workbook is:

```text
excel\cases.xlsx
```

It contains three sheets:

- `Cases`: one row per case
- `Follow Ups`: multiple follow-up entries linked by `Case ID`
- `Categories`: allowed issue and concern categories

The `Cases` sheet columns are:

```text
Case ID
Date Collected
Employee Name
Employee ID
Employee's Manager
Issue / Concern Category
Accused Employee
Investigation Link
Case Summary
Sensitivity Level
Case Status
Last Updated
Group ID
Group Name
Group Status
Group Notes
```

The `Follow Ups` sheet uses:

```text
Case ID
Follow-Up Date
Follow-Up Notes
```

## Executive Summary

Click **Generate Executive Summary** after loading the workbook. The output is calculated from fixed rules in the browser and does not use AI or an outside service.

When the workbook is empty, the summary reports zero records and zero open or closed cases. Once records are entered, the summary reports counts and percentages calculated from the workbook fields.

From a selected case, **Generate Case Narrative** creates a short factual description from recorded fields and follow-up notes. It does not infer findings or conclusions.

The narrative is available after a case is entered and selected. It uses only the recorded case fields and follow-up notes.

## Project Files

Required files:

- `index.html`: dashboard page
- `assets/app.js`: dashboard behavior, Excel parsing, filtering, metrics, and saving
- `assets/styles.css`: layout and styling
- `assets/default-workbook.js`: embedded blank workbook used when the page first opens
- `data/cases.xlsx`: blank workbook source
- `excel/cases.xlsx`: workbook to import and maintain

Do not separate `index.html` from the `assets` folder or the embedded workbook script.

## Troubleshooting

If the dashboard is empty, click **New Case** to enter a record or click **Import Excel** to load an existing workbook.

If **Save to Excel** downloads a file instead of updating the workbook, the browser does not support direct file writing. Use the downloaded workbook as the replacement for `excel\cases.xlsx`.

If imported data does not appear, confirm the workbook contains `Cases`, `Follow Ups`, and `Categories` sheets with the expected headers.

The dashboard is intended for local use. Protect the project folder and workbook with the same access controls used for other HR or employee-relations records.
