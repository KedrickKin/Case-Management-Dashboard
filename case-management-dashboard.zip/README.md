# Case Management Dashboard

A local dashboard for tracking employee workplace concern cases. It is designed for HR, employee relations, and compliance teams that need to create, review, filter, group, and summarize sensitive records without sending data to an outside service.

## Run It

1. Keep the entire project folder together.
2. Double-click `index.html`.
3. The dashboard opens with data saved in the current browser, when available. On first use, click **Import Excel** to load an existing workbook, or click **New Case** to start a new set of records.
4. In Chrome or Edge, select the workbook through **Import Excel** to connect it for two-way syncing. Approve read/write access when the browser asks.

There is no server, command file, package installation, or terminal step required.

## Browser Storage and Excel Backups

The dashboard saves imported and changed case data automatically in the browser using IndexedDB, with `localStorage` as a fallback. When the page opens again in the same browser profile, it loads that saved copy automatically, so users do not need to import the workbook every time.

- Browser storage is local to that browser profile and device. It does not sync to other people or computers, and clearing browser data can remove it. For a shared copy, select a workbook in a shared, locally synchronized folder such as OneDrive; the storage provider syncs that file between people.
- This browser storage is not encrypted by the dashboard. Protect the computer and browser profile as you would the Excel workbook, and use **Export Excel** regularly for a separate backup.
- **Import Excel** replaces the current records with workbook data and saves that copy in the browser. If the import differs from existing browser records, the dashboard asks before replacing them. In supported Chrome and Edge versions, selecting the workbook through the file picker also lets the app remember the connection in IndexedDB, subject to browser permission.
- The dashboard checks the connected workbook on startup, when the tab becomes active, and about every 20 seconds while visible. If only the workbook changed, the browser copy updates automatically.
- If both the browser and workbook changed since their last sync, the dashboard pauses and asks whether to load the workbook version, keep browser edits and update the workbook, or decide later. It checks the file again before writing so a newer edit is not silently overwritten.
- Case changes save in sequence to the browser and then to the connected workbook. If a browser save is still pending, the page warns before it closes or refreshes. Click **Sync now** to check or sync immediately.
- **Save to Excel** saves a workbook copy. If the workbook was imported through a standard file chooser or the browser cannot write directly to it, saving opens a save picker when available or downloads an updated `.xlsx` copy. **Export Excel** always downloads a separate `.xlsx` copy.
- If the browser cannot keep a selected-file connection, browser storage still works; the dashboard status will say to reselect the workbook or use Excel export for a portable copy.
- To sync across people, select a workbook file in a shared, locally synchronized folder. The dashboard checks that file for changes; it does not provide a server or merge edits automatically when multiple people changed the workbook.

The save status beside the case table shows whether data is loading, saving, stored in this browser, synced to the selected workbook, or whether access or conflict resolution is needed.

## Dashboard Features

- Create, view, edit, search, and filter cases.
- Delete a selected case after a confirmation prompt. Its follow-up entries are removed with it.
- Separate **Open Cases**, **Closed Cases**, and **All Cases** tabs.
- Open a closed case and use **Reopen Case** when work resumes.
- Track multiple follow-up dates and notes per case.
- Link cases involving the same accused employee during the same general period.
- Review linked-case details and possible matching cases.
- View metrics, aging, follow-up health, issue mix, status mix, and monthly graphs.
- Generate a rule-based executive summary without AI.
- Generate a factual, rule-based narrative for each selected case without AI.
- Use Privacy Mode to abbreviate names and mask employee IDs while reviewing records.

## Case Fields

Each case can include:

- Date collected
- Reporting employee name and employee ID
- Employee manager
- Issue or concern category
- Accused employee
- Investigation URL
- Case summary
- Sensitivity level
- Case status
- Linked concern group details
- Multiple follow-up dates and notes

The investigation URL is displayed using the reporting employee's name when privacy mode is off. The dashboard rejects unsafe URL schemes such as `javascript:`.

## Case Tabs And Filters

Use the case tabs to switch between open, closed, and all records. The table supports sorting by Case ID, date, employee, manager, issue, linked group, accused employee, and follow-up status.

Filters include:

- Search text
- Issue category
- Manager
- Accused employee
- Follow-up status
- Linked concern group
- Date collected range

## Linked Concern Groups

Grouping is for cases where two or more reporting employees are talking about the same accused employee during the same general period.

For example, two reporting employees can be linked when they name the same accused employee during the same general period. Both cases can then be tracked together without treating them as one report.

A group does not mean the reports have the same outcome. It only connects records that may describe the same underlying period or subject. The dashboard may suggest possible matches, but the user decides whether to link them.

## Metrics And Graphs

The **Metrics** tab includes:

- Total, open, and closed case counts
- Cases needing follow-up
- High-sensitivity open cases
- Average open-case age
- New cases in the last 30 days
- Linked group count and potential matches
- Closure rate and follow-up health
- Issue category mix
- Linked group status
- Oldest open cases

Graphs show cases by month, status mix, and top issue types. Metric cards include contributing case IDs when records exist so totals can be traced back to records.

## Workbook Format

The supplied workbook is:

```text
excel\cases.xlsx
```

It contains three sheets:

- `Cases`: one row per case
- `Follow Ups`: multiple follow-up entries linked by `Case ID`
- `Categories`: allowed issue and concern categories

The `Cases` sheet columns are:

```text
Case ID
Date Collected
Employee Name
Employee ID
Employee's Manager
Issue / Concern Category
Accused Employee
Investigation Link
Case Summary
Sensitivity Level
Case Status
Last Updated
Group ID
Group Name
Group Status
Group Notes
```

The `Follow Ups` sheet uses:

```text
Case ID
Follow-Up Date
Follow-Up Notes
```

## Executive Summary

Click **Generate Executive Summary** after loading the workbook. The output is calculated from fixed rules in the browser and does not use AI or an outside service.

When the workbook is empty, the summary reports zero records and zero open or closed cases. Once records are entered, the summary reports counts and percentages calculated from the workbook fields.

From a selected case, **Generate Case Narrative** creates a short factual description from recorded fields and follow-up notes. It does not infer findings or conclusions.

The narrative is available after a case is entered and selected. It uses only the recorded case fields and follow-up notes.

## Project Files

Required files:

- `index.html`: dashboard page
- `assets/app.js`: dashboard behavior, Excel parsing, filtering, metrics, and saving
- `assets/styles.css`: layout and styling
- `assets/default-workbook.js`: embedded blank workbook used when the page first opens
- `data/cases.xlsx`: blank workbook source
- `excel/cases.xlsx`: workbook to import and maintain

Do not separate `index.html` from the `assets` folder or the embedded workbook script.

## Troubleshooting

If the dashboard is empty on first use, click **New Case** to enter a record or click **Import Excel** to load an existing workbook. If a prior browser-saved copy is missing, confirm you are using the same browser profile and have not cleared its site data. If the connected workbook is no longer available, choose it again with **Import Excel** and grant access.

If **Save to Excel** downloads a file instead of updating the workbook, the browser does not support direct file writing. Use the downloaded workbook as the replacement for `excel\cases.xlsx`.

If imported data does not appear, confirm the workbook contains `Cases`, `Follow Ups`, and `Categories` sheets with the expected headers.

The dashboard is intended for local use. Protect the project folder and workbook with the same access controls used for other HR or employee-relations records.
