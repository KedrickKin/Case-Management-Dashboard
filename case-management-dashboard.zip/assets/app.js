"use strict";

const ISSUE_CATEGORIES = [
  "Discrimination",
  "Stagnation / lack of advancement",
  "Unfair treatment",
  "Retaliation",
  "Harassment",
  "Bullying",
  "Policy violation",
  "Pay or benefits concern",
  "Scheduling concern",
  "Workplace safety",
  "Performance management concern",
  "Ethics or compliance concern",
  "Accommodation request",
  "Other",
];

const FOLLOW_STATUS_OPTIONS = [
  "All follow-up statuses",
  "Current",
  "Needs review",
  "Upcoming",
  "No follow-up",
  "Closed",
];

const GROUP_STATUS_OPTIONS = ["Monitoring", "Active review", "Resolved"];

const MONTH_LABELS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

const CASE_TABS = [
  { id: "open", label: "Open Cases", resultLabel: "open case" },
  { id: "closed", label: "Closed Cases", resultLabel: "closed case" },
  { id: "all", label: "All Cases", resultLabel: "case" },
];

const SORT_LABELS = {
  caseId: "Case ID",
  dateCollected: "Date",
  employeeName: "Employee",
  manager: "Manager",
  category: "Issue",
  groupName: "Linked Group",
  accusedEmployee: "Accused",
  followStatus: "Follow-up",
};

const CASE_HEADERS = [
  "Case ID",
  "Date Collected",
  "Employee Name",
  "Employee ID",
  "Employee's Manager",
  "Issue / Concern Category",
  "Accused Employee",
  "Investigation Link",
  "Case Summary",
  "Sensitivity Level",
  "Case Status",
  "Last Updated",
  "Group ID",
  "Group Name",
  "Group Status",
  "Group Notes",
];

const FOLLOW_UP_HEADERS = ["Case ID", "Follow-Up Date", "Follow-Up Notes"];
const EXCEL_FILE_PICKER_TYPES = [{
  description: "Excel workbook",
  accept: { "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet": [".xlsx"] },
}];

const state = {
  cases: [],
  followUps: [],
  categories: [...ISSUE_CATEGORIES],
  viewTab: "cases",
  caseTab: "open",
  filters: createEmptyFilters(),
  sort: { key: "dateCollected", direction: "desc" },
  selectedCaseId: "",
  privacyMode: true,
  dirty: false,
  sourceName: "Embedded Excel snapshot",
  browserWorkbookHandle: null,
  saveStatus: "Use Import Excel to choose a workbook",
  executiveSummaryText: "",
  summaryCopyLabel: "Copy Summary",
  summaryDownloadName: "executive-summary.txt",
};

const qs = (selector, root = document) => root.querySelector(selector);
const qsa = (selector, root = document) => Array.from(root.querySelectorAll(selector));

document.addEventListener("DOMContentLoaded", init);

async function init() {
  bindEvents();
  try {
    const source = await loadDefaultWorkbook();
    const workbook = await parseXlsx(source.buffer);
    hydrateFromWorkbook(workbook, source);
  } catch (error) {
    console.error(error);
    hydrateFallbackData();
    state.sourceName = "Blank workbook";
  }
  render();
}

function bindEvents() {
  qs("#privacyToggle").addEventListener("change", (event) => {
    state.privacyMode = event.target.checked;
    render();
  });

  qs("#importButton").addEventListener("click", () => chooseWorkbookForImport());
  qs("#workbookInput").addEventListener("change", handleWorkbookImport);
  qs("#exportButton").addEventListener("click", exportWorkbook);
  qs("#saveButton").addEventListener("click", () => saveWorkbookToExcel({ manual: true }));
  qs("#summaryButton").addEventListener("click", openExecutiveSummary);
  qs("#newCaseButton").addEventListener("click", () => openCaseForm());
  qs("#clearFiltersButton").addEventListener("click", clearFilters);
  qs("#viewTabs").addEventListener("click", (event) => {
    const button = event.target.closest("button[data-view-tab]");
    if (!button) return;
    state.viewTab = button.dataset.viewTab;
    render();
  });
  qs("#caseTabs").addEventListener("click", (event) => {
    const button = event.target.closest("button[data-case-tab]");
    if (!button) return;
    state.caseTab = button.dataset.caseTab;
    render();
  });

  const filterIds = [
    "searchInput",
    "categoryFilter",
    "managerFilter",
    "accusedFilter",
    "followStatusFilter",
    "groupFilter",
    "dateFromFilter",
    "dateToFilter",
  ];
  for (const id of filterIds) {
    qs(`#${id}`).addEventListener("input", updateFiltersFromInputs);
  }

  qs("thead").addEventListener("click", (event) => {
    const button = event.target.closest("button[data-sort]");
    if (!button) return;
    updateSort(button.dataset.sort);
  });

  qs("#caseTableBody").addEventListener("click", (event) => {
    const row = event.target.closest("tr[data-case-id]");
    if (!row) return;
    state.selectedCaseId = row.dataset.caseId;
    render();
  });

  qs("#detailPanel").addEventListener("click", (event) => {
    const button = event.target.closest("button[data-select-case]");
    if (!button) return;
    const selectedCase = state.cases.find((item) => item.caseId === button.dataset.selectCase);
    if (!selectedCase) return;
    state.selectedCaseId = selectedCase.caseId;
    syncActiveTabForCase(selectedCase);
    resetFilters();
    render();
  });

  qs("#closeDialogButton").addEventListener("click", closeCaseForm);
  qs("#cancelFormButton").addEventListener("click", closeCaseForm);
  qs("#closeSummaryButton").addEventListener("click", closeExecutiveSummary);
  qs("#closeSummaryFooterButton").addEventListener("click", closeExecutiveSummary);
  qs("#copySummaryButton").addEventListener("click", copyExecutiveSummary);
  qs("#downloadSummaryButton").addEventListener("click", downloadExecutiveSummary);
  qs('select[name="groupId"]').addEventListener("change", handleGroupSelectionChange);
  qs("#addFollowUpButton").addEventListener("click", () => addFollowUpField());
  qs("#caseForm").addEventListener("submit", saveCaseFromForm);
  qs("#followUpFields").addEventListener("click", (event) => {
    const button = event.target.closest("button[data-remove-followup]");
    if (!button) return;
    button.closest(".followup-row").remove();
  });
}

async function loadDefaultWorkbook() {
  // A file:// page cannot read a neighboring workbook automatically. The
  // bundled snapshot keeps the page usable until the user imports an Excel file.
  if (window.DEFAULT_WORKBOOK_BASE64) {
    return {
      buffer: base64ToArrayBuffer(window.DEFAULT_WORKBOOK_BASE64),
      name: "Embedded Excel snapshot",
    };
  }

  try {
    const response = await fetch("data/cases.xlsx", { cache: "no-store" });
    if (response.ok) {
      return {
        buffer: await response.arrayBuffer(),
        name: "data/cases.xlsx",
      };
    }
  } catch (error) {
    console.info("Using embedded workbook fallback.", error);
  }

  if (window.DEFAULT_WORKBOOK_BASE64) {
    return {
      buffer: base64ToArrayBuffer(window.DEFAULT_WORKBOOK_BASE64),
      name: "Embedded Excel snapshot",
    };
  }

  throw new Error("No workbook source was available.");
}

async function handleWorkbookImport(event) {
  const file = event.target.files?.[0];
  if (!file) return;

  await importWorkbookFile(file);
  event.target.value = "";
}

async function chooseWorkbookForImport() {
  if (typeof window.showOpenFilePicker === "function") {
    try {
      const [handle] = await window.showOpenFilePicker({
        multiple: false,
        types: EXCEL_FILE_PICKER_TYPES,
        excludeAcceptAllOption: true,
      });
      if (!handle) return;
      await importWorkbookFile(await handle.getFile(), handle);
      return;
    } catch (error) {
      if (error?.name === "AbortError") return;
      console.info("Direct Excel file picker unavailable; using the browser file chooser.", error);
    }
  }

  qs("#workbookInput").click();
}

async function importWorkbookFile(file, fileHandle = null) {
  try {
    const workbook = await parseXlsx(await file.arrayBuffer());
    hydrateFromWorkbook(workbook, file.name);
    state.browserWorkbookHandle = fileHandle;
    state.dirty = false;
    state.saveStatus = fileHandle
      ? "Excel file loaded; save ready"
      : "Excel file loaded; use Save to Excel for a copy";
    render();
  } catch (error) {
    console.error(error);
    alert("This workbook could not be read. Check that it follows the Cases and Follow Ups sheet format.");
  }
}

function hydrateFromWorkbook(workbook, source) {
  const casesRows = workbook.sheets.Cases || [];
  const followRows = workbook.sheets["Follow Ups"] || workbook.sheets.FollowUps || [];
  const categoryRows = workbook.sheets.Categories || [];

  state.categories = extractCategories(categoryRows);
  state.cases = parseCaseRows(casesRows);
  state.followUps = parseFollowUpRows(followRows);
  const sourceName = typeof source === "string" ? source : source?.name;
  state.sourceName = sourceName || "Embedded Excel snapshot";
  state.saveStatus = "Use Import Excel to choose a workbook";
  selectInitialCase();
}

function hydrateFallbackData() {
  state.categories = [...ISSUE_CATEGORIES];
  state.cases = [];
  state.followUps = [];
  state.saveStatus = "Use Import Excel to choose a workbook";
  selectInitialCase();
}

function parseCaseRows(rows) {
  if (!rows.length) return [];
  const headers = makeHeaderIndex(rows[0]);
  return rows.slice(1).map((row) => ({
    caseId: textValue(row, headers, "Case ID"),
    dateCollected: dateValue(row, headers, "Date Collected"),
    employeeName: textValue(row, headers, "Employee Name"),
    employeeId: textValue(row, headers, "Employee ID"),
    manager: textValue(row, headers, "Employee's Manager", "Employee Manager", "Manager"),
    category: textValue(row, headers, "Issue / Concern Category", "Issue Category", "Issue / Concern"),
    accusedEmployee: textValue(row, headers, "Accused Employee"),
    investigationLink: textValue(row, headers, "Investigation Link"),
    summary: textValue(row, headers, "Case Summary", "Summary"),
    sensitivity: textValue(row, headers, "Sensitivity Level", "Sensitivity") || "Moderate",
    caseStatus: textValue(row, headers, "Case Status", "Status") || "Open",
    lastUpdated: dateValue(row, headers, "Last Updated") || dateValue(row, headers, "Date Collected"),
    groupId: textValue(row, headers, "Group ID", "Case Group ID", "Similar Case Group ID"),
    groupName: textValue(row, headers, "Group Name", "Case Group", "Similar Case Group"),
    groupStatus: textValue(row, headers, "Group Status") || "Monitoring",
    groupNotes: textValue(row, headers, "Group Notes", "Group Rationale", "Similar Case Group Notes"),
  })).filter((record) => record.caseId || record.employeeName || record.employeeId);
}

function parseFollowUpRows(rows) {
  if (!rows.length) return [];
  const headers = makeHeaderIndex(rows[0]);
  return rows.slice(1).map((row) => ({
    caseId: textValue(row, headers, "Case ID"),
    date: dateValue(row, headers, "Follow-Up Date", "Follow Up Date", "Follow-Up Dates"),
    notes: textValue(row, headers, "Follow-Up Notes", "Follow Up Notes", "Notes"),
  })).filter((record) => record.caseId && (record.date || record.notes));
}

function extractCategories(rows) {
  const found = rows.slice(1).map((row) => String(row[0] || "").trim()).filter(Boolean);
  return found.length ? found : [...ISSUE_CATEGORIES];
}

function makeHeaderIndex(headerRow) {
  const index = new Map();
  headerRow.forEach((header, position) => {
    index.set(normalizeHeader(header), position);
  });
  return index;
}

function textValue(row, headers, ...names) {
  const value = rawValue(row, headers, names);
  if (value == null) return "";
  if (typeof value === "number") return String(value);
  return String(value).trim();
}

function dateValue(row, headers, ...names) {
  const value = rawValue(row, headers, names);
  return normalizeDate(value);
}

function rawValue(row, headers, names) {
  for (const name of names) {
    const position = headers.get(normalizeHeader(name));
    if (position != null) return row[position];
  }
  return "";
}

function normalizeHeader(value) {
  return String(value || "").toLowerCase().replace(/[^a-z0-9]/g, "");
}

function render() {
  renderFilterOptions();
  renderStats();
  renderViewTabs();
  renderCaseTabs();
  renderTable();
  renderDetails();
  renderMetrics();
  renderSortLabels();
  renderPersistenceStatus();
}

function renderPersistenceStatus() {
  const status = qs("#saveStatus");
  const dirtyBadge = qs("#dirtyBadge");
  if (!status || !dirtyBadge) return;

  status.textContent = state.saveStatus;
  status.className = "save-status";
  if (!state.browserWorkbookHandle) status.classList.add("is-warning");
  if (state.saveStatus.toLowerCase().startsWith("saving")) status.classList.add("is-saving");
  if (state.saveStatus.toLowerCase().startsWith("save failed")) status.classList.add("is-error");
  dirtyBadge.hidden = !state.dirty;
}

function renderFilterOptions() {
  setSelectOptions("#categoryFilter", ["All categories", ...state.categories], state.filters.category);
  setSelectOptions("#managerFilter", ["All managers", ...uniqueValues(state.cases.map((item) => item.manager))], state.filters.manager);
  setSelectOptions("#accusedFilter", ["All accused employees", ...uniqueValues(state.cases.map((item) => item.accusedEmployee))], state.filters.accused);
  setSelectOptions("#followStatusFilter", FOLLOW_STATUS_OPTIONS, state.filters.followStatus);
  setSelectOptions("#groupFilter", [
    { value: "", label: "All linked groups" },
    { value: "__ungrouped", label: "Ungrouped" },
    ...getCaseGroups().map((group) => ({
      value: group.id,
      label: `${maskSensitiveText(group.name)} (${group.caseIds.length})`,
    })),
  ], state.filters.group);

  qs("#searchInput").value = state.filters.search;
  qs("#dateFromFilter").value = state.filters.dateFrom;
  qs("#dateToFilter").value = state.filters.dateTo;
}

function setSelectOptions(selector, options, value) {
  const select = qs(selector);
  const current = value || "";
  select.innerHTML = options.map((option, index) => {
    const optionValue = typeof option === "object" ? option.value : (index === 0 ? "" : option);
    const optionLabel = typeof option === "object" ? option.label : option;
    return `<option value="${escapeAttribute(optionValue)}">${escapeHtml(optionLabel)}</option>`;
  }).join("");
  select.value = current;
}

function renderStats() {
  const allCases = state.cases;
  const openCases = allCases.filter((item) => !isClosedCase(item)).length;
  const groupedCases = allCases.filter((item) => getGroupKey(item)).length;
  const needsFollowUp = allCases.filter((item) => {
    const status = getFollowUpStatus(item).label;
    return !isClosedCase(item) && (status === "Needs review" || status === "No follow-up");
  }).length;

  qs("#totalCases").textContent = String(allCases.length);
  qs("#openCases").textContent = String(openCases);
  qs("#needsFollowUp").textContent = String(needsFollowUp);
  qs("#groupedCases").textContent = String(groupedCases);
  qs("#sourceLabel").textContent = state.sourceName;
}

function renderViewTabs() {
  for (const button of qsa("[data-view-tab]")) {
    const active = button.dataset.viewTab === state.viewTab;
    button.classList.toggle("is-active", active);
    button.setAttribute("aria-selected", String(active));
  }

  qs("#casesView").hidden = state.viewTab !== "cases";
  qs("#metricsView").hidden = state.viewTab !== "metrics";
}

function renderCaseTabs() {
  const counts = getCaseTabCounts();
  for (const button of qsa("[data-case-tab]")) {
    const tabId = button.dataset.caseTab;
    const active = tabId === state.caseTab;
    button.classList.toggle("is-active", active);
    button.setAttribute("aria-selected", String(active));
    const count = button.querySelector(".case-tab-count");
    if (count) count.textContent = String(counts[tabId] ?? 0);
  }
}

function renderTable() {
  const rows = getVisibleCases();
  const body = qs("#caseTableBody");
  const label = getActiveCaseTab().resultLabel;
  qs("#resultCount").textContent = `${rows.length} ${rows.length === 1 ? label : `${label}s`}`;
  qs("#emptyState").hidden = rows.length > 0;

  if (!rows.length) {
    body.innerHTML = "";
    return;
  }

  if (!rows.some((item) => item.caseId === state.selectedCaseId)) {
    state.selectedCaseId = rows[0].caseId;
  }

  body.innerHTML = rows.map((item) => {
    const followStatus = getFollowUpStatus(item);
    const selected = item.caseId === state.selectedCaseId ? " is-selected" : "";
    return `
      <tr class="case-row${selected}" data-case-id="${escapeAttribute(item.caseId)}">
        <td><span class="case-id">${escapeHtml(item.caseId)}</span></td>
        <td>${formatDate(item.dateCollected)}</td>
        <td class="truncate">${escapeHtml(maskName(item.employeeName))}<br><small>${escapeHtml(maskId(item.employeeId))}</small></td>
        <td class="truncate">${escapeHtml(maskName(item.manager))}</td>
        <td><span class="pill">${escapeHtml(item.category || "Other")}</span></td>
        <td class="truncate"><span class="pill group">${escapeHtml(getGroupDisplayLabel(item))}</span></td>
        <td class="truncate">${escapeHtml(maskName(item.accusedEmployee || "Not specified"))}</td>
        <td><span class="pill ${followStatus.className}">${escapeHtml(followStatus.label)}</span></td>
      </tr>
    `;
  }).join("");
}

function renderDetails() {
  const rows = getVisibleCases();
  const panel = qs("#detailPanel");
  const item = rows.find((record) => record.caseId === state.selectedCaseId) || rows[0];

  if (!item) {
    panel.innerHTML = `<div class="detail-empty">Select or create a case to view details.</div>`;
    return;
  }

  state.selectedCaseId = item.caseId;
  const followUps = getFollowUps(item.caseId);
  const followStatus = getFollowUpStatus(item);
  const group = getCaseGroup(item);
  const relatedCases = getRelatedCases(item);
  const suggestedCases = getSuggestedCases(item);
  const safeLink = safeHttpUrl(item.investigationLink);
  const linkLabel = state.privacyMode
    ? "Investigation link"
    : `${item.employeeName || "Employee"} investigation`;

  panel.innerHTML = `
    <div class="detail-title-row">
      <div>
        <p class="eyebrow">${escapeHtml(item.caseId)}</p>
        <h2>${escapeHtml(state.privacyMode ? "Protected employee record" : item.employeeName || "Employee record")}</h2>
        <div class="detail-meta">
          <span class="pill ${followStatus.className}">${escapeHtml(followStatus.label)}</span>
          <span class="pill ${riskClass(item.sensitivity)}">${escapeHtml(item.sensitivity || "Moderate")}</span>
          <span class="pill">${escapeHtml(item.caseStatus || "Open")}</span>
          <span class="pill group">${escapeHtml(getGroupDisplayLabel(item))}</span>
        </div>
      </div>
      <div class="detail-actions">
        ${isClosedCase(item) ? `<button class="secondary-button" type="button" id="reopenCaseButton">Reopen Case</button>` : ""}
        <button class="secondary-button" type="button" id="caseNarrativeButton">Generate Case Narrative</button>
        <button class="secondary-button" type="button" id="editCaseButton">Edit</button>
        <button class="danger-button" type="button" id="deleteCaseButton">Delete Case</button>
      </div>
    </div>

    <div class="detail-grid">
      ${detailField("Date Collected", formatDate(item.dateCollected))}
      ${detailField("Employee", `${maskName(item.employeeName)} / ${maskId(item.employeeId)}`)}
      ${detailField("Manager", maskName(item.manager))}
      ${detailField("Issue Category", item.category || "Other")}
      ${detailField("Accused Employee", maskName(item.accusedEmployee || "Not specified"))}
      ${detailField("Last Updated", formatDate(item.lastUpdated))}
      ${detailField("Investigation", safeLink ? `<a class="link-action" href="${escapeAttribute(safeLink)}" target="_blank" rel="noreferrer">${escapeHtml(linkLabel)}</a>` : "No link provided", true)}
      ${detailField("Follow-Up Entries", String(followUps.length))}
      ${detailField("Linked Concern Group", group ? maskSensitiveText(group.name) : "Ungrouped")}
      ${detailField("Tracking Status", group ? group.status : "Not assigned")}
    </div>

    <div class="summary-box">${escapeHtml(item.summary || "No summary entered.")}</div>

    ${renderGroupPanel(group, relatedCases, suggestedCases)}

    <div class="section-heading">
      <h3>Follow-Up Notes</h3>
    </div>
    <div class="timeline">
      ${followUps.length ? followUps.map((entry) => `
        <div class="timeline-entry">
          <div class="timeline-date">${formatDate(entry.date)}</div>
          <div class="timeline-note">${escapeHtml(entry.notes || "No note entered.")}</div>
        </div>
      `).join("") : `<div class="timeline-entry"><div class="timeline-date">None</div><div class="timeline-note">No follow-up entries are recorded.</div></div>`}
    </div>
  `;

  qs("#editCaseButton").addEventListener("click", () => openCaseForm(item.caseId));
  qs("#caseNarrativeButton").addEventListener("click", () => openCaseNarrative(item.caseId));
  qs("#deleteCaseButton").addEventListener("click", () => deleteCase(item.caseId));
  const reopenButton = qs("#reopenCaseButton");
  if (reopenButton) {
    reopenButton.addEventListener("click", () => reopenCase(item.caseId));
  }
}

function renderGroupPanel(group, relatedCases, suggestedCases) {
  if (!group) {
    return `
      <section class="group-panel">
        <div class="section-heading">
          <h3>Linked Concern Tracking</h3>
          <span class="pill no-follow-up">Ungrouped</span>
        </div>
        <p class="group-note">No linked concern group assigned.</p>
        ${suggestedCases.length ? `
          <div class="related-list">
            <span>Possible same-employee period matches</span>
            ${suggestedCases.map((item) => relatedCaseButton(item)).join("")}
          </div>
        ` : ""}
      </section>
    `;
  }

  return `
    <section class="group-panel">
      <div class="section-heading">
        <h3>${escapeHtml(maskSensitiveText(group.name))}</h3>
        <span class="pill group">${escapeHtml(group.status)}</span>
      </div>
      <p class="group-note">${escapeHtml(maskSensitiveText(group.notes || "No group notes entered."))}</p>
      <div class="related-list">
        <span>${relatedCases.length} linked ${relatedCases.length === 1 ? "case" : "cases"}</span>
        ${relatedCases.length ? relatedCases.map((item) => relatedCaseButton(item)).join("") : `<p>No other cases are assigned to this linked group.</p>`}
      </div>
    </section>
  `;
}

function renderMetrics() {
  const metrics = getDashboardMetrics();

  qs("#metricsOverview").innerHTML = [
    metricCard("Open Cases", metrics.openCount, "Active case workload", metrics.openCaseRefs),
    metricCard("Needs Follow-Up", metrics.attentionNeeded, "Needs review or no follow-up", metrics.attentionCaseRefs),
    metricCard("High Sensitivity", metrics.highSensitivityOpen, "Open cases marked high", metrics.highSensitivityCaseRefs),
    metricCard("Avg Open Age", formatDays(metrics.averageOpenAge), "Oldest open cases", metrics.oldestOpenCaseRefs),
    metricCard("New In 30 Days", metrics.newLast30Days, "Recently collected cases", metrics.recentCaseRefs),
    metricCard("Linked Groups", metrics.linkedGroupCount, "Named employee and period links", metrics.linkedCaseRefs),
    metricCard("Potential Links", metrics.potentialLinkedCases, "Ungrouped possible matches", metrics.potentialLinkRefs),
    metricCard("Closure Rate", `${metrics.closureRate}%`, "Closed cases out of total", metrics.closedCaseRefs),
  ].join("");

  qs("#monthlyCaseGraph").innerHTML = renderVerticalChart(metrics.monthRows, "No monthly case data.");
  qs("#statusGraph").innerHTML = renderGraphRows(metrics.statusRows, "No case statuses recorded.");
  qs("#issueGraph").innerHTML = renderGraphRows(metrics.issueGraphRows, "No issue categories recorded.");
  qs("#followUpMetrics").innerHTML = renderMetricRows(metrics.followUpRows, "No open follow-up activity.");
  qs("#categoryMetrics").innerHTML = renderMetricRows(metrics.categoryRows, "No issue categories recorded.");
  qs("#linkedGroupMetrics").innerHTML = renderLinkedGroupMetrics(metrics.linkedGroups);
  qs("#ageMetrics").innerHTML = renderAgeMetrics(metrics.oldestOpenCases);
}

function metricCard(label, value, context, caseRefs = []) {
  return `
    <article class="metric-card">
      <span>${escapeHtml(label)}</span>
      <strong>${escapeHtml(value)}</strong>
      <small>${escapeHtml(context)}</small>
      <div class="metric-card-cases">
        ${caseRefs.length
          ? caseRefs.map((caseId) => `<span class="metric-case-chip">${escapeHtml(caseId)}</span>`).join("")
          : `<span class="metric-case-chip">No cases</span>`}
      </div>
    </article>
  `;
}

function renderMetricRows(rows, emptyText) {
  if (!rows.length) {
    return `<div class="metric-row"><strong>${escapeHtml(emptyText)}</strong></div>`;
  }

  return rows.map((row) => {
    const percent = clampPercent(row.percent);
    return `
      <div class="metric-row">
        <div>
          <strong>${escapeHtml(row.label)}</strong>
          <span>${escapeHtml(row.context || `${percent}% of cases`)}</span>
        </div>
        <div class="metric-value">${escapeHtml(row.count)}</div>
        <div class="metric-bar-track" aria-hidden="true">
          <div class="metric-bar" style="width: ${percent}%"></div>
        </div>
      </div>
    `;
  }).join("");
}

function renderVerticalChart(rows, emptyText) {
  if (!rows.length) {
    return `<div class="metric-row"><strong>${escapeHtml(emptyText)}</strong></div>`;
  }

  const max = Math.max(...rows.map((row) => row.count), 1);
  return rows.map((row) => {
    const percent = clampPercent((row.count / max) * 100);
    return `
      <div class="vertical-bar" aria-label="${escapeAttribute(`${row.label}: ${row.count} cases`)}">
        <div class="vertical-bar-fill-wrap">
          <div class="vertical-bar-fill" style="height: ${percent}%"></div>
        </div>
        <div class="vertical-bar-value">${escapeHtml(row.count)}</div>
        <div class="vertical-bar-label">${escapeHtml(row.label)}</div>
      </div>
    `;
  }).join("");
}

function renderGraphRows(rows, emptyText) {
  if (!rows.length) {
    return `<div class="metric-row"><strong>${escapeHtml(emptyText)}</strong></div>`;
  }

  return rows.map((row) => {
    const percent = clampPercent(row.percent);
    return `
      <div class="graph-row">
        <strong>${escapeHtml(row.label)}</strong>
        <div class="graph-row-value">${escapeHtml(row.count)}</div>
        <span>${escapeHtml(row.context || `${percent}% of cases`)}</span>
        <div class="graph-track" aria-hidden="true">
          <div class="graph-fill" style="width: ${percent}%"></div>
        </div>
      </div>
    `;
  }).join("");
}

function renderLinkedGroupMetrics(groups) {
  if (!groups.length) {
    return `<div class="metric-row"><strong>No linked concern groups yet.</strong></div>`;
  }

  return groups.map((group) => `
    <div class="metric-row">
      <div>
        <strong>${escapeHtml(maskSensitiveText(group.name))}</strong>
        <span>${escapeHtml(`${group.dateSpan} | ${group.openCount} open | ${group.attentionNeeded} need follow-up`)}</span>
      </div>
      <div class="metric-value">${escapeHtml(group.caseCount)}</div>
    </div>
  `).join("");
}

function renderAgeMetrics(cases) {
  if (!cases.length) {
    return `<div class="metric-row"><strong>No open cases.</strong></div>`;
  }

  return cases.map((item) => `
    <div class="metric-row">
      <div>
        <strong>${escapeHtml(item.caseId)} - ${escapeHtml(item.category || "Other")}</strong>
        <span>${escapeHtml(`${item.followStatus} | collected ${formatDate(item.dateCollected)}`)}</span>
      </div>
      <div class="metric-value">${escapeHtml(formatDays(item.daysOpen))}</div>
    </div>
  `).join("");
}

function relatedCaseButton(item) {
  return `
    <button class="related-case-button" type="button" data-select-case="${escapeAttribute(item.caseId)}">
      <strong>${escapeHtml(item.caseId)}</strong>
      <span>${escapeHtml(state.privacyMode ? item.category : `${item.category} - ${item.employeeName}`)}</span>
    </button>
  `;
}

function detailField(label, value, containsHtml = false) {
  return `
    <div class="detail-field">
      <span>${escapeHtml(label)}</span>
      <strong>${containsHtml ? value : escapeHtml(value || "Not specified")}</strong>
    </div>
  `;
}

function renderSortLabels() {
  for (const button of qsa("th button[data-sort]")) {
    const key = button.dataset.sort;
    const active = key === state.sort.key;
    button.textContent = active
      ? `${SORT_LABELS[key]} ${state.sort.direction}`
      : SORT_LABELS[key];
    button.parentElement.setAttribute(
      "aria-sort",
      active ? (state.sort.direction === "asc" ? "ascending" : "descending") : "none",
    );
  }
}

function updateFiltersFromInputs() {
  state.filters.search = qs("#searchInput").value.trim();
  state.filters.category = qs("#categoryFilter").value;
  state.filters.manager = qs("#managerFilter").value;
  state.filters.accused = qs("#accusedFilter").value;
  state.filters.followStatus = qs("#followStatusFilter").value;
  state.filters.group = qs("#groupFilter").value;
  state.filters.dateFrom = qs("#dateFromFilter").value;
  state.filters.dateTo = qs("#dateToFilter").value;
  render();
}

function clearFilters() {
  resetFilters();
  render();
}

function resetFilters() {
  state.filters = createEmptyFilters();
}

function createEmptyFilters() {
  return {
    search: "",
    category: "",
    manager: "",
    accused: "",
    followStatus: "",
    group: "",
    dateFrom: "",
    dateTo: "",
  };
}

function updateSort(key) {
  if (state.sort.key === key) {
    state.sort.direction = state.sort.direction === "asc" ? "desc" : "asc";
  } else {
    state.sort.key = key;
    state.sort.direction = key === "dateCollected" ? "desc" : "asc";
  }
  render();
}

function getVisibleCases() {
  const search = state.filters.search.toLowerCase();
  const filtered = state.cases.filter((item) => {
    const matchesTab = state.caseTab === "all"
      || (state.caseTab === "closed" ? isClosedCase(item) : !isClosedCase(item));
    const followStatus = getFollowUpStatus(item).label;
    const groupKey = getGroupKey(item);
    const text = [
      item.caseId,
      item.dateCollected,
      item.employeeName,
      item.employeeId,
      item.manager,
      item.category,
      item.accusedEmployee,
      item.summary,
      item.caseStatus,
      item.groupId,
      item.groupName,
      item.groupStatus,
      item.groupNotes,
      ...getFollowUps(item.caseId).map((entry) => `${entry.date} ${entry.notes}`),
    ].join(" ").toLowerCase();

    return matchesTab
      && (!search || text.includes(search))
      && (!state.filters.category || item.category === state.filters.category)
      && (!state.filters.manager || item.manager === state.filters.manager)
      && (!state.filters.accused || item.accusedEmployee === state.filters.accused)
      && (!state.filters.followStatus || followStatus === state.filters.followStatus)
      && (!state.filters.group || (state.filters.group === "__ungrouped" ? !groupKey : groupKey === state.filters.group))
      && (!state.filters.dateFrom || item.dateCollected >= state.filters.dateFrom)
      && (!state.filters.dateTo || item.dateCollected <= state.filters.dateTo);
  });

  return filtered.sort(compareCases);
}

function compareCases(a, b) {
  const direction = state.sort.direction === "asc" ? 1 : -1;
  const key = state.sort.key;
  const aValue = key === "followStatus" ? getFollowUpStatus(a).label : key === "groupName" ? getGroupLabel(a) : a[key] || "";
  const bValue = key === "followStatus" ? getFollowUpStatus(b).label : key === "groupName" ? getGroupLabel(b) : b[key] || "";
  return String(aValue).localeCompare(String(bValue), undefined, {
    numeric: true,
    sensitivity: "base",
  }) * direction;
}

function getActiveCaseTab() {
  return CASE_TABS.find((tab) => tab.id === state.caseTab) || CASE_TABS[0];
}

function getCaseTabCounts() {
  return state.cases.reduce((counts, item) => {
    counts.all += 1;
    if (isClosedCase(item)) {
      counts.closed += 1;
    } else {
      counts.open += 1;
    }
    return counts;
  }, { open: 0, closed: 0, all: 0 });
}

function getDashboardMetrics() {
  const today = todayString();
  const allCases = state.cases;
  const openCases = allCases.filter((item) => !isClosedCase(item));
  const closedCases = allCases.filter((item) => isClosedCase(item));
  const openAges = openCases.map((item) => getCaseAgeDays(item, today));
  const followUpRows = buildFollowUpRows(openCases);
  const attentionCases = openCases.filter((item) => {
    const status = getFollowUpStatus(item).label;
    return status === "Needs review" || status === "No follow-up";
  });
  const highSensitivityCases = openCases.filter((item) => String(item.sensitivity).toLowerCase() === "high");
  const recentCases = allCases.filter((item) => isWithinPastDays(item.dateCollected, today, 30));
  const potentialLinkCases = openCases.filter((item) => !getGroupKey(item) && getSuggestedCases(item).length);
  const linkedCases = allCases.filter((item) => getGroupKey(item));
  const oldestOpenCases = openCases
    .map((item) => ({
      caseId: item.caseId,
      category: item.category,
      dateCollected: item.dateCollected,
      followStatus: getFollowUpStatus(item).label,
      daysOpen: getCaseAgeDays(item, today),
    }))
    .sort((a, b) => b.daysOpen - a.daysOpen || a.caseId.localeCompare(b.caseId))
    .slice(0, 5);

  return {
    total: allCases.length,
    openCount: openCases.length,
    closedCount: closedCases.length,
    attentionNeeded: attentionCases.length,
    highSensitivityOpen: highSensitivityCases.length,
    averageOpenAge: average(openAges),
    newLast30Days: recentCases.length,
    linkedGroupCount: getCaseGroups().length,
    potentialLinkedCases: potentialLinkCases.length,
    closureRate: allCases.length ? Math.round((closedCases.length / allCases.length) * 100) : 0,
    openCaseRefs: caseRefs(openCases),
    attentionCaseRefs: caseRefs(attentionCases),
    highSensitivityCaseRefs: caseRefs(highSensitivityCases),
    oldestOpenCaseRefs: oldestOpenCases.map((item) => item.caseId).slice(0, 4),
    recentCaseRefs: caseRefs(recentCases),
    linkedCaseRefs: caseRefs(linkedCases),
    potentialLinkRefs: caseRefs(potentialLinkCases),
    closedCaseRefs: caseRefs(closedCases),
    monthRows: buildMonthlyRows(allCases),
    statusRows: countRows(allCases, (item) => item.caseStatus || "Open", allCases.length),
    issueGraphRows: countRows(allCases, (item) => item.category || "Other", allCases.length).slice(0, 6),
    followUpRows,
    categoryRows: countRows(allCases, (item) => item.category || "Other", allCases.length).slice(0, 6),
    linkedGroups: buildLinkedGroupRows(openCases),
    oldestOpenCases,
  };
}

function buildFollowUpRows(openCases) {
  const total = openCases.length;
  const counts = countBy(openCases, (item) => getFollowUpStatus(item).label);
  return ["Needs review", "No follow-up", "Upcoming", "Current"].map((label) => {
    const count = counts.get(label) || 0;
    return {
      label,
      count,
      percent: total ? Math.round((count / total) * 100) : 0,
      context: total ? `${Math.round((count / total) * 100)}% of open cases` : "0 open cases",
    };
  });
}

function buildLinkedGroupRows(openCases) {
  return getCaseGroups().map((group) => {
    const cases = state.cases.filter((item) => group.caseIds.includes(item.caseId));
    const openInGroup = cases.filter((item) => !isClosedCase(item));
    const attentionNeeded = openInGroup.filter((item) => {
      const status = getFollowUpStatus(item).label;
      return status === "Needs review" || status === "No follow-up";
    }).length;

    return {
      name: group.name,
      caseCount: cases.length,
      openCount: openInGroup.length,
      attentionNeeded,
      dateSpan: formatDateSpan(cases.map((item) => item.dateCollected)),
      status: group.status,
      activeInOpenView: openCases.some((item) => group.caseIds.includes(item.caseId)),
    };
  }).sort((a, b) => (
    b.attentionNeeded - a.attentionNeeded
    || b.openCount - a.openCount
    || b.caseCount - a.caseCount
    || a.name.localeCompare(b.name, undefined, { sensitivity: "base" })
  ));
}

function countRows(items, labeler, total = items.length) {
  return [...countBy(items, labeler).entries()]
    .map(([label, count]) => ({
      label,
      count,
      percent: total ? Math.round((count / total) * 100) : 0,
    }))
    .sort((a, b) => b.count - a.count || a.label.localeCompare(b.label, undefined, { sensitivity: "base" }));
}

function caseRefs(items, limit = 4) {
  return [...items]
    .sort((a, b) => String(b.dateCollected).localeCompare(String(a.dateCollected)) || a.caseId.localeCompare(b.caseId))
    .slice(0, limit)
    .map((item) => item.caseId);
}

function buildMonthlyRows(items) {
  const counts = countBy(items.filter((item) => item.dateCollected), (item) => monthKey(item.dateCollected));
  return [...counts.entries()]
    .sort(([a], [b]) => a.localeCompare(b))
    .slice(-8)
    .map(([key, count]) => ({
      label: formatMonthKey(key),
      count,
      key,
    }));
}

function monthKey(value) {
  const date = normalizeDate(value);
  return date ? date.slice(0, 7) : "Unknown";
}

function formatMonthKey(key) {
  const [year, month] = String(key).split("-");
  const monthIndex = Number(month) - 1;
  if (!year || !Number.isInteger(monthIndex) || monthIndex < 0 || monthIndex > 11) return key;
  return `${MONTH_LABELS[monthIndex]} ${year.slice(-2)}`;
}

function countBy(items, labeler) {
  const counts = new Map();
  for (const item of items) {
    const label = String(labeler(item) || "Not specified");
    counts.set(label, (counts.get(label) || 0) + 1);
  }
  return counts;
}

function average(values) {
  const valid = values.filter((value) => Number.isFinite(value));
  if (!valid.length) return 0;
  return Math.round(valid.reduce((sum, value) => sum + value, 0) / valid.length);
}

function getCaseAgeDays(item, today = todayString()) {
  if (!item.dateCollected) return 0;
  return Math.max(0, daysBetween(item.dateCollected, today));
}

function isWithinPastDays(dateValue, today, days) {
  if (!dateValue) return false;
  const age = daysBetween(dateValue, today);
  return age >= 0 && age <= days;
}

function clampPercent(value) {
  const numeric = Number(value);
  if (!Number.isFinite(numeric)) return 0;
  return Math.max(0, Math.min(100, Math.round(numeric)));
}

function isClosedCase(item) {
  return String(item?.caseStatus || "").trim().toLowerCase() === "closed";
}

function selectInitialCase() {
  const openCase = state.cases.find((item) => !isClosedCase(item));
  const firstCase = openCase || state.cases[0];
  state.caseTab = openCase || !state.cases.length ? "open" : "closed";
  state.selectedCaseId = firstCase?.caseId || "";
  resetFilters();
}

function syncActiveTabForCase(item) {
  if (!item || state.caseTab === "all") return;
  state.caseTab = isClosedCase(item) ? "closed" : "open";
}

function reopenCase(caseId) {
  const item = state.cases.find((record) => record.caseId === caseId);
  if (!item) return;
  item.caseStatus = "Open";
  item.lastUpdated = todayString();
  state.selectedCaseId = item.caseId;
  state.caseTab = "open";
  state.dirty = true;
  render();
  void saveWorkbookToExcel();
}

function deleteCase(caseId) {
  const item = state.cases.find((record) => record.caseId === caseId);
  if (!item) return false;

  const label = state.privacyMode
    ? item.caseId
    : `${item.caseId}${item.employeeName ? ` for ${item.employeeName}` : ""}`;
  const confirmed = typeof window.confirm === "function"
    && window.confirm(`Delete case ${label}? This will also remove its follow-up entries.`);
  if (!confirmed) return false;

  state.cases = state.cases.filter((record) => record.caseId !== caseId);
  state.followUps = state.followUps.filter((entry) => entry.caseId !== caseId);
  state.selectedCaseId = "";
  state.dirty = true;
  render();
  void saveWorkbookToExcel();
  return true;
}

function getFollowUps(caseId) {
  return state.followUps
    .filter((entry) => entry.caseId === caseId)
    .sort((a, b) => String(a.date).localeCompare(String(b.date)));
}

function getGroupKey(item) {
  return (item.groupId || item.groupName || "").trim();
}

function getGroupLabel(item) {
  return getGroupKey(item) ? (item.groupName || item.groupId) : "Ungrouped";
}

function getGroupDisplayLabel(item) {
  return maskSensitiveText(getGroupLabel(item));
}

function getCaseGroups() {
  const groups = new Map();
  for (const item of state.cases) {
    const key = getGroupKey(item);
    if (!key) continue;

    if (!groups.has(key)) {
      groups.set(key, {
        id: key,
        name: item.groupName || key,
        status: item.groupStatus || "Monitoring",
        notes: item.groupNotes || "",
        caseIds: [],
      });
    }

    const group = groups.get(key);
    group.caseIds.push(item.caseId);
    if (!group.name && item.groupName) group.name = item.groupName;
    if (!group.notes && item.groupNotes) group.notes = item.groupNotes;
    if (!group.status && item.groupStatus) group.status = item.groupStatus;
  }

  return [...groups.values()].sort((a, b) => a.name.localeCompare(b.name, undefined, { sensitivity: "base" }));
}

function getCaseGroup(item) {
  const key = getGroupKey(item);
  if (!key) return null;
  return getCaseGroups().find((group) => group.id === key) || null;
}

function getRelatedCases(item) {
  const key = getGroupKey(item);
  if (!key) return [];
  return state.cases
    .filter((candidate) => candidate.caseId !== item.caseId && getGroupKey(candidate) === key)
    .sort((a, b) => String(b.dateCollected).localeCompare(String(a.dateCollected)));
}

function getSuggestedCases(item) {
  if (getGroupKey(item)) return [];
  return state.cases
    .filter((candidate) => candidate.caseId !== item.caseId)
    .map((candidate) => {
      let score = 0;
      const sameAccused = candidate.accusedEmployee
        && item.accusedEmployee
        && candidate.accusedEmployee === item.accusedEmployee;
      const closePeriod = isCloseCasePeriod(candidate, item);
      if (sameAccused) score += 5;
      if (closePeriod) score += 3;
      if (candidate.category && candidate.category === item.category) score += 1;
      if (candidate.manager && candidate.manager === item.manager) score += 1;
      if (candidate.caseStatus !== "Closed") score += 1;
      return { candidate, score };
    })
    .filter((entry) => entry.score >= 7)
    .sort((a, b) => b.score - a.score || String(b.candidate.dateCollected).localeCompare(String(a.candidate.dateCollected)))
    .slice(0, 4)
    .map((entry) => entry.candidate);
}

function isCloseCasePeriod(a, b) {
  if (!a.dateCollected || !b.dateCollected) return false;
  return Math.abs(daysBetween(a.dateCollected, b.dateCollected)) <= 60;
}

function getFollowUpStatus(item) {
  if (item.caseStatus === "Closed") return { label: "Closed", className: "closed" };

  const entries = getFollowUps(item.caseId).filter((entry) => entry.date);
  if (!entries.length) return { label: "No follow-up", className: "no-follow-up" };

  const today = todayString();
  if (entries.some((entry) => entry.date >= today)) {
    return { label: "Upcoming", className: "upcoming" };
  }

  const latest = entries[entries.length - 1]?.date || item.dateCollected;
  const daysSince = daysBetween(latest, today);
  if (daysSince > 21) return { label: "Needs review", className: "needs-review" };
  return { label: "Current", className: "current" };
}

function openCaseForm(caseId = "") {
  const dialog = qs("#caseDialog");
  const form = qs("#caseForm");
  const item = state.cases.find((record) => record.caseId === caseId) || makeBlankCase();
  const followUps = caseId ? getFollowUps(caseId) : [];

  qs("#caseFormTitle").textContent = caseId ? `Edit ${item.caseId}` : "New Case";
  qs("#formError").hidden = true;
  fillCategorySelect(qs('select[name="category"]'));
  fillGroupSelect(qs('select[name="groupId"]'), getGroupKey(item));

  form.elements.caseId.value = item.caseId;
  form.elements.dateCollected.value = item.dateCollected;
  form.elements.employeeName.value = item.employeeName;
  form.elements.employeeId.value = item.employeeId;
  form.elements.manager.value = item.manager;
  form.elements.category.value = item.category || state.categories[0] || "Other";
  form.elements.accusedEmployee.value = item.accusedEmployee;
  form.elements.investigationLink.value = item.investigationLink;
  form.elements.sensitivity.value = item.sensitivity || "Moderate";
  form.elements.caseStatus.value = item.caseStatus || "Open";
  form.elements.groupName.value = item.groupName || "";
  form.elements.groupStatus.value = item.groupStatus || "Monitoring";
  form.elements.groupNotes.value = item.groupNotes || "";
  form.elements.summary.value = item.summary || "";

  qs("#followUpFields").innerHTML = "";
  if (followUps.length) {
    for (const entry of followUps) addFollowUpField(entry);
  } else {
    addFollowUpField();
  }

  if (typeof dialog.showModal === "function") {
    dialog.showModal();
  } else {
    dialog.setAttribute("open", "");
  }
}

function closeCaseForm() {
  const dialog = qs("#caseDialog");
  if (typeof dialog.close === "function") {
    dialog.close();
  } else {
    dialog.removeAttribute("open");
  }
}

function openExecutiveSummary() {
  openGeneratedTextDialog(buildExecutiveSummary(), {
    title: "Executive Summary",
    assurance: "Rule-based summary generated locally from the loaded workbook. No AI or external service is used.",
    copyLabel: "Copy Summary",
    downloadName: `executive-summary-${todayString()}.txt`,
  });
}

function openCaseNarrative(caseId) {
  const item = state.cases.find((record) => record.caseId === caseId);
  if (!item) return;

  openGeneratedTextDialog(buildCaseNarrative(item), {
    title: `Case Narrative: ${item.caseId}`,
    assurance: "Rule-based narrative generated locally from this case record. No AI or external service is used.",
    copyLabel: "Copy Narrative",
    downloadName: `case-narrative-${item.caseId}.txt`,
  });
}

function openGeneratedTextDialog(summary, options) {
  state.executiveSummaryText = summary.text;
  state.summaryCopyLabel = options.copyLabel;
  state.summaryDownloadName = options.downloadName;
  qs("#summaryDialogTitle").textContent = options.title;
  qs("#summaryAssurance").textContent = options.assurance;
  qs("#copySummaryButton").textContent = options.copyLabel;
  qs("#executiveSummaryContent").innerHTML = summary.html;

  const dialog = qs("#summaryDialog");
  if (typeof dialog.showModal === "function") {
    dialog.showModal();
  } else {
    dialog.setAttribute("open", "");
  }
}

function closeExecutiveSummary() {
  const dialog = qs("#summaryDialog");
  if (typeof dialog.close === "function") {
    dialog.close();
  } else {
    dialog.removeAttribute("open");
  }
}

function copyExecutiveSummary() {
  if (!state.executiveSummaryText) return;

  const button = qs("#copySummaryButton");
  const markCopied = () => {
    const originalLabel = state.summaryCopyLabel || "Copy Summary";
    button.textContent = "Copied";
    window.setTimeout(() => { button.textContent = originalLabel; }, 1400);
  };

  if (navigator.clipboard?.writeText) {
    navigator.clipboard.writeText(state.executiveSummaryText).then(markCopied).catch(() => {
      copyTextWithSelection(state.executiveSummaryText, markCopied);
    });
    return;
  }

  copyTextWithSelection(state.executiveSummaryText, markCopied);
}

function copyTextWithSelection(value, onSuccess) {
  const helper = document.createElement("textarea");
  helper.value = value;
  helper.setAttribute("readonly", "");
  helper.style.position = "fixed";
  helper.style.opacity = "0";
  document.body.appendChild(helper);
  helper.select();
  const copied = document.execCommand("copy");
  helper.remove();
  if (copied) onSuccess();
}

function downloadExecutiveSummary() {
  if (!state.executiveSummaryText) return;

  const blob = new Blob([state.executiveSummaryText], { type: "text/plain;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = state.summaryDownloadName || `executive-summary-${todayString()}.txt`;
  document.body.appendChild(link);
  link.click();
  link.remove();
  URL.revokeObjectURL(url);
}

function buildExecutiveSummary() {
  const today = todayString();
  const metrics = getDashboardMetrics();
  const allCases = state.cases;
  const openCases = allCases.filter((item) => !isClosedCase(item));
  const closedCases = allCases.filter((item) => isClosedCase(item));
  const attentionCases = openCases.filter((item) => {
    const status = getFollowUpStatus(item).label;
    return status === "Needs review" || status === "No follow-up";
  });
  const highSensitivityCases = openCases.filter((item) => String(item.sensitivity).toLowerCase() === "high");
  const categoryRows = countRows(allCases, (item) => item.category || "Other", allCases.length).slice(0, 5);
  const statusRows = countRows(allCases, (item) => item.caseStatus || "Open", allCases.length);
  const groups = getCaseGroups().map((group) => {
    const groupCases = state.cases.filter((item) => group.caseIds.includes(item.caseId));
    return {
      ...group,
      caseCount: groupCases.length,
      openCount: groupCases.filter((item) => !isClosedCase(item)).length,
      dateSpan: formatDateSpan(groupCases.map((item) => item.dateCollected)),
    };
  }).sort((a, b) => b.openCount - a.openCount || b.caseCount - a.caseCount || a.name.localeCompare(b.name));
  const oldestCases = [...openCases]
    .sort((a, b) => getCaseAgeDays(b, today) - getCaseAgeDays(a, today) || a.caseId.localeCompare(b.caseId))
    .slice(0, 5);
  const followUpCounts = ["Needs review", "No follow-up", "Upcoming", "Current"]
    .map((label) => ({ label, count: openCases.filter((item) => getFollowUpStatus(item).label === label).length }));
  const sourceLabel = state.sourceName || "Loaded workbook";
  const dateLabel = formatDate(today);
  const privacyNote = state.privacyMode ? "Names are masked because Privacy mode is on." : "Names are shown because Privacy mode is off.";

  if (!allCases.length) {
    return {
      text: [
        "EXECUTIVE SUMMARY",
        `Generated: ${dateLabel}`,
        `Source: ${sourceLabel}`,
        "",
        "No case records are currently loaded.",
        privacyNote,
      ].join("\n"),
      html: `
        <div class="summary-empty">
          <h3>No case records are currently loaded.</h3>
          <p>Import an Excel workbook or add a new case to generate a fuller summary.</p>
        </div>
      `,
    };
  }

  const overviewText = `The workbook contains ${allCases.length} ${allCases.length === 1 ? "case" : "cases"}: ${openCases.length} open and ${closedCases.length} closed. The current closure rate is ${metrics.closureRate}%.`;
  const followUpText = openCases.length
    ? `${attentionCases.length} open ${attentionCases.length === 1 ? "case needs" : "cases need"} follow-up attention based on no follow-up activity or a follow-up older than 21 days.`
    : "There are no open cases requiring follow-up review.";
  const groupingText = metrics.linkedGroupCount
    ? `${metrics.linkedGroupCount} linked concern ${metrics.linkedGroupCount === 1 ? "group is" : "groups are"} recorded, covering ${allCases.filter((item) => getGroupKey(item)).length} ${allCases.filter((item) => getGroupKey(item)).length === 1 ? "case" : "cases"}.`
    : "No linked concern groups are recorded.";

  const textLines = [
    "EXECUTIVE SUMMARY",
    `Generated: ${dateLabel}`,
    `Source: ${sourceLabel}`,
    "Scope: All cases currently loaded, including unsaved browser changes.",
    "",
    "OVERVIEW",
    overviewText,
    `Average age of open cases: ${formatDays(metrics.averageOpenAge)}.`,
    `New cases in the last 30 days: ${metrics.newLast30Days}.`,
    "",
    "STATUS MIX",
    ...statusRows.map((row) => `- ${row.label}: ${row.count} (${row.percent}%)`),
    "",
    "FOLLOW-UP",
    followUpText,
    ...followUpCounts.map((row) => `- ${row.label}: ${row.count}`),
    "",
    "ISSUE MIX",
    ...categoryRows.map((row) => `- ${row.label}: ${row.count} (${row.percent}%)`),
    "",
    "LINKED CONCERN GROUPS",
    groupingText,
    ...groups.slice(0, 5).map((group) => `- ${maskSensitiveText(group.name)}: ${group.caseCount} cases, ${group.openCount} open, ${group.dateSpan}`),
    "",
    "REVIEW FOCUS",
    `- High-sensitivity open cases: ${highSensitivityCases.length}`,
    `- Open cases needing follow-up attention: ${attentionCases.length}`,
    ...oldestCases.slice(0, 3).map((item) => `- Oldest open case: ${item.caseId}, ${item.category || "Other"}, collected ${formatDate(item.dateCollected)}, ${formatDays(getCaseAgeDays(item, today))} open`),
    privacyNote,
    "",
    "This summary is calculated from workbook fields using fixed rules. It does not use AI or send data outside this browser.",
  ];

  const html = `
    <div class="summary-meta-grid">
      ${summaryStat("As of", dateLabel)}
      ${summaryStat("Records", allCases.length)}
      ${summaryStat("Open", openCases.length)}
      ${summaryStat("Closed", closedCases.length)}
    </div>
    ${summarySection("Overview", `
      <p>${escapeHtml(overviewText)}</p>
      <div class="summary-fact-row">
        ${summaryFact("Average open age", formatDays(metrics.averageOpenAge))}
        ${summaryFact("New in 30 days", metrics.newLast30Days)}
        ${summaryFact("Closure rate", `${metrics.closureRate}%`)}
      </div>
    `)}
    ${summarySection("Status Mix", statusRows.length
      ? `<ul class="summary-list">${statusRows.map((row) => `<li><span>${escapeHtml(row.label)}</span><strong>${escapeHtml(`${row.count} (${row.percent}%)`)}</strong></li>`).join("")}</ul>`
      : "<p>No case statuses are recorded.</p>")}
    ${summarySection("Follow-Up", `
      <p>${escapeHtml(followUpText)}</p>
      <ul class="summary-list">${followUpCounts.map((row) => `<li><span>${escapeHtml(row.label)}</span><strong>${escapeHtml(row.count)}</strong></li>`).join("")}</ul>
    `)}
    ${summarySection("Issue Mix", categoryRows.length
      ? `<ul class="summary-list">${categoryRows.map((row) => `<li><span>${escapeHtml(row.label)}</span><strong>${escapeHtml(`${row.count} (${row.percent}%)`)}</strong></li>`).join("")}</ul>`
      : "<p>No issue categories are recorded.</p>")}
    ${summarySection("Linked Concern Groups", `
      <p>${escapeHtml(groupingText)}</p>
      ${groups.length ? `<ul class="summary-list">${groups.slice(0, 5).map((group) => `<li><span>${escapeHtml(maskSensitiveText(group.name))}<small>${escapeHtml(`${group.dateSpan} | ${group.openCount} open`)}</small></span><strong>${escapeHtml(group.caseCount)}</strong></li>`).join("")}</ul>` : ""}
    `)}
    ${summarySection("Review Focus", `
      <ul class="summary-list">
        <li><span>High-sensitivity open cases</span><strong>${escapeHtml(highSensitivityCases.length)}</strong></li>
        <li><span>Open cases needing follow-up attention</span><strong>${escapeHtml(attentionCases.length)}</strong></li>
        ${oldestCases.slice(0, 3).map((item) => `<li><span>${escapeHtml(`${item.caseId} | ${item.category || "Other"}`)}<small>${escapeHtml(`Collected ${formatDate(item.dateCollected)} | ${formatDays(getCaseAgeDays(item, today))} open`)}</small></span><strong>Open</strong></li>`).join("")}
      </ul>
    `)}
    <p class="summary-footnote">${escapeHtml(privacyNote)} Calculated from workbook fields using fixed rules. No AI or external service is used.</p>
  `;

  return { text: textLines.join("\n"), html };
}

function buildCaseNarrative(item) {
  const followUps = getFollowUps(item.caseId);
  const group = getCaseGroup(item);
  const relatedCases = getRelatedCases(item);
  const employee = item.employeeName ? maskName(item.employeeName) : "The reporting employee";
  const manager = item.manager ? maskName(item.manager) : "Not specified";
  const accused = item.accusedEmployee ? maskName(item.accusedEmployee) : "Not specified";
  const category = item.category || "Other";
  const status = item.caseStatus || "Open";
  const sensitivity = item.sensitivity || "Moderate";
  const recordedSummary = maskSensitiveText(item.summary || "").trim();
  const narrativeParagraphs = [
    `On ${formatDate(item.dateCollected)}, ${employee} reported a ${category} concern involving ${accused}. The employee's manager is ${manager}.`,
    recordedSummary ? `The recorded case summary states: ${recordedSummary}` : "No case summary was entered.",
    `The case is currently ${status} and is marked ${sensitivity} sensitivity.`,
  ];
  const followUpLines = followUps.length
    ? followUps.map((entry) => `- ${formatDate(entry.date)}: ${maskSensitiveText(entry.notes || "No note entered.")}`)
    : ["No follow-up entries are recorded."];
  const groupText = group
    ? `This case is linked to ${maskSensitiveText(group.name)} with ${relatedCases.length} other ${relatedCases.length === 1 ? "case" : "cases"} in the same group.${group.notes ? ` The group note states: ${maskSensitiveText(group.notes)}` : ""}`
    : "This case is not assigned to a linked concern group.";
  const investigationText = safeHttpUrl(item.investigationLink)
    ? "A related outside investigation page is recorded for this case."
    : "No outside investigation link is recorded for this case.";
  const text = [
    "CASE NARRATIVE",
    `Case ID: ${item.caseId}`,
    `Date collected: ${formatDate(item.dateCollected)}`,
    `Last updated: ${formatDate(item.lastUpdated)}`,
    "",
    "NARRATIVE",
    ...narrativeParagraphs,
    "",
    "FOLLOW-UP HISTORY",
    ...followUpLines,
    "",
    "LINKED CONCERN CONTEXT",
    groupText,
    investigationText,
    state.privacyMode ? "Names are masked because Privacy mode is on." : "Names are shown because Privacy mode is off.",
    "",
    "This narrative is assembled from recorded case fields using fixed rules. It does not use AI or send data outside this browser.",
  ];
  const html = `
    <div class="summary-meta-grid">
      ${summaryStat("Case ID", item.caseId)}
      ${summaryStat("Date Collected", formatDate(item.dateCollected))}
      ${summaryStat("Status", status)}
      ${summaryStat("Sensitivity", sensitivity)}
    </div>
    ${summarySection("Narrative", narrativeParagraphs.map((paragraph) => `<p>${escapeHtml(paragraph)}</p>`).join(""))}
    ${summarySection("Follow-Up History", `<ul class="summary-list">${followUpLines.map((line) => `<li><span>${escapeHtml(line.replace(/^- /, ""))}</span></li>`).join("")}</ul>`)}
    ${summarySection("Linked Concern Context", `<p>${escapeHtml(groupText)}</p><p>${escapeHtml(investigationText)}</p>`)}
    <p class="summary-footnote">${escapeHtml(state.privacyMode ? "Names are masked because Privacy mode is on." : "Names are shown because Privacy mode is off.")} Assembled from recorded case fields using fixed rules. No AI or external service is used.</p>
  `;

  return { text: text.join("\n"), html };
}

function summarySection(title, content) {
  return `<section class="summary-section"><h3>${escapeHtml(title)}</h3>${content}</section>`;
}

function summaryStat(label, value) {
  return `<div class="summary-stat"><span>${escapeHtml(label)}</span><strong>${escapeHtml(value)}</strong></div>`;
}

function summaryFact(label, value) {
  return `<div class="summary-fact"><span>${escapeHtml(label)}</span><strong>${escapeHtml(value)}</strong></div>`;
}

function makeBlankCase() {
  const today = todayString();
  return {
    caseId: nextCaseId(),
    dateCollected: today,
    employeeName: "",
    employeeId: "",
    manager: "",
    category: state.categories[0] || "Other",
    accusedEmployee: "",
    investigationLink: "",
    summary: "",
    sensitivity: "Moderate",
    caseStatus: "Open",
    lastUpdated: today,
    groupId: "",
    groupName: "",
    groupStatus: "Monitoring",
    groupNotes: "",
  };
}

function fillCategorySelect(select) {
  select.innerHTML = state.categories
    .map((category) => `<option value="${escapeAttribute(category)}">${escapeHtml(category)}</option>`)
    .join("");
}

function fillGroupSelect(select, selectedKey = "") {
  const options = [
    { value: "", label: "No linked group" },
    { value: "__new", label: "Create linked group" },
    ...getCaseGroups().map((group) => ({
      value: group.id,
      label: `${group.name} (${group.caseIds.length})`,
    })),
  ];

  select.innerHTML = options
    .map((option) => `<option value="${escapeAttribute(option.value)}">${escapeHtml(option.label)}</option>`)
    .join("");

  select.value = selectedKey && options.some((option) => option.value === selectedKey) ? selectedKey : "";
}

function handleGroupSelectionChange(event) {
  const value = event.target.value;
  const form = qs("#caseForm");

  if (!value) {
    form.elements.groupName.value = "";
    form.elements.groupStatus.value = "Monitoring";
    form.elements.groupNotes.value = "";
    return;
  }

  if (value === "__new") {
    form.elements.groupName.value = "";
    form.elements.groupStatus.value = "Monitoring";
    form.elements.groupNotes.value = "";
    form.elements.groupName.focus();
    return;
  }

  const group = getCaseGroups().find((item) => item.id === value);
  if (!group) return;

  form.elements.groupName.value = group.name;
  form.elements.groupStatus.value = group.status || "Monitoring";
  form.elements.groupNotes.value = group.notes || "";
}

function addFollowUpField(entry = { date: "", notes: "" }) {
  const wrapper = document.createElement("div");
  wrapper.className = "followup-row";
  wrapper.innerHTML = `
    <label>
      <span>Date</span>
      <input type="date" name="followUpDate" value="${escapeAttribute(entry.date || "")}" />
    </label>
    <label>
      <span>Notes</span>
      <textarea name="followUpNotes" rows="2">${escapeHtml(entry.notes || "")}</textarea>
    </label>
    <button class="icon-button" type="button" data-remove-followup aria-label="Remove follow-up">&times;</button>
  `;
  qs("#followUpFields").appendChild(wrapper);
}

function saveCaseFromForm(event) {
  event.preventDefault();

  const form = event.currentTarget;
  const errorBox = qs("#formError");
  const selectedGroup = form.elements.groupId.value;
  const groupName = form.elements.groupName.value.trim();
  const assignedGroupId = selectedGroup === "__new" || (!selectedGroup && groupName)
    ? (groupName ? nextGroupId() : "")
    : selectedGroup;
  const caseRecord = {
    caseId: form.elements.caseId.value.trim(),
    dateCollected: form.elements.dateCollected.value,
    employeeName: form.elements.employeeName.value.trim(),
    employeeId: form.elements.employeeId.value.trim(),
    manager: form.elements.manager.value.trim(),
    category: form.elements.category.value,
    accusedEmployee: form.elements.accusedEmployee.value.trim() || "Not specified",
    investigationLink: form.elements.investigationLink.value.trim(),
    summary: form.elements.summary.value.trim(),
    sensitivity: form.elements.sensitivity.value,
    caseStatus: form.elements.caseStatus.value,
    lastUpdated: todayString(),
    groupId: assignedGroupId,
    groupName: assignedGroupId ? (groupName || assignedGroupId) : "",
    groupStatus: assignedGroupId ? form.elements.groupStatus.value : "Monitoring",
    groupNotes: assignedGroupId ? form.elements.groupNotes.value.trim() : "",
  };

  const validation = validateCase(caseRecord);
  if (validation) {
    errorBox.textContent = validation;
    errorBox.hidden = false;
    return;
  }

  const existingIndex = state.cases.findIndex((item) => item.caseId === caseRecord.caseId);
  if (existingIndex >= 0) {
    state.cases.splice(existingIndex, 1, caseRecord);
  } else {
    state.cases.push(caseRecord);
  }

  if (caseRecord.groupId) {
    for (const item of state.cases) {
      if (item.caseId !== caseRecord.caseId && getGroupKey(item) === caseRecord.groupId) {
        item.groupName = caseRecord.groupName;
        item.groupStatus = caseRecord.groupStatus;
        item.groupNotes = caseRecord.groupNotes;
      }
    }
  }

  const followUps = qsa(".followup-row").map((row) => ({
    caseId: caseRecord.caseId,
    date: qs('input[name="followUpDate"]', row).value,
    notes: qs('textarea[name="followUpNotes"]', row).value.trim(),
  })).filter((entry) => entry.date || entry.notes);

  state.followUps = state.followUps.filter((entry) => entry.caseId !== caseRecord.caseId).concat(followUps);
  state.selectedCaseId = caseRecord.caseId;
  syncActiveTabForCase(caseRecord);
  state.dirty = true;
  closeCaseForm();
  render();
  void saveWorkbookToExcel();
}

function validateCase(item) {
  if (!item.dateCollected || !item.employeeName || !item.employeeId || !item.manager || !item.category) {
    return "Date collected, employee, employee ID, manager, and category are required.";
  }

  if (item.investigationLink && !safeHttpUrl(item.investigationLink)) {
    return "Investigation links must begin with http:// or https://.";
  }

  if ((item.groupId || item.groupName || item.groupNotes) && !item.groupName) {
    return "Add a group name when assigning a case to a linked concern group.";
  }

  return "";
}

function nextCaseId() {
  const year = new Date().getFullYear();
  const pattern = new RegExp(`^ER-${year}-(\\d+)$`);
  const next = state.cases.reduce((max, item) => {
    const match = item.caseId.match(pattern);
    return match ? Math.max(max, Number(match[1])) : max;
  }, 0) + 1;
  return `ER-${year}-${String(next).padStart(3, "0")}`;
}

function nextGroupId() {
  const year = new Date().getFullYear();
  const pattern = new RegExp(`^GRP-${year}-(\\d+)$`);
  const next = state.cases.reduce((max, item) => {
    const match = String(item.groupId || "").match(pattern);
    return match ? Math.max(max, Number(match[1])) : max;
  }, 0) + 1;
  return `GRP-${year}-${String(next).padStart(3, "0")}`;
}

function saveWorkbookToExcel({ manual = false } = {}) {
  if (!manual && !state.browserWorkbookHandle) {
    state.saveStatus = state.dirty
      ? "Unsaved changes; use Save to Excel"
      : "Use Import Excel to choose a workbook";
    renderPersistenceStatus();
    return Promise.resolve(false);
  }
  return saveWorkbookToBrowserFile();
}

async function saveWorkbookToBrowserFile() {
  const workbookBytes = buildWorkbookBytes();
  let writable;

  try {
    let handle = state.browserWorkbookHandle;
    if (!handle && typeof window.showSaveFilePicker === "function") {
      handle = await window.showSaveFilePicker({
        suggestedName: "cases.xlsx",
        types: EXCEL_FILE_PICKER_TYPES,
        excludeAcceptAllOption: true,
      });
    }

    if (handle) {
      if (typeof handle.requestPermission === "function") {
        const permission = await handle.requestPermission({ mode: "readwrite" });
        if (permission !== "granted") throw new Error("Write permission was not granted.");
      }
      writable = await handle.createWritable();
      await writable.write(workbookBytes);
      await writable.close();
      state.browserWorkbookHandle = handle;
      state.dirty = false;
      state.sourceName = handle.name || "Selected Excel workbook";
      state.saveStatus = `Saved to ${handle.name || "selected Excel workbook"}`;
      render();
      return true;
    }

    exportWorkbook();
    state.dirty = false;
    state.saveStatus = "Excel copy downloaded";
    render();
    return true;
  } catch (error) {
    if (writable && typeof writable.abort === "function") await writable.abort().catch(() => {});
    if (error?.name === "AbortError") {
      state.saveStatus = "Save cancelled; changes remain unsaved";
      renderPersistenceStatus();
      return false;
    }
    console.error(error);
    state.dirty = true;
    state.saveStatus = "Save failed; changes remain unsaved";
    render();
    alert("The workbook could not be saved. Grant write access or use Export Excel to download a copy.");
    return false;
  }
}

function exportWorkbook() {
  const workbookBytes = buildWorkbookBytes();
  const blob = new Blob([workbookBytes], {
    type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
  });
  const link = document.createElement("a");
  link.href = URL.createObjectURL(blob);
  link.download = "case-management-cases.xlsx";
  document.body.appendChild(link);
  link.click();
  link.remove();
  URL.revokeObjectURL(link.href);
  render();
}

function buildWorkbookBytes() {
  const caseRows = [
    CASE_HEADERS,
    ...state.cases.map((item) => [
      item.caseId,
      item.dateCollected,
      item.employeeName,
      item.employeeId,
      item.manager,
      item.category,
      item.accusedEmployee,
      item.investigationLink,
      item.summary,
      item.sensitivity,
      item.caseStatus,
      item.lastUpdated || item.dateCollected,
      item.groupId,
      item.groupName,
      item.groupStatus,
      item.groupNotes,
    ]),
  ];

  const followRows = [
    FOLLOW_UP_HEADERS,
    ...state.followUps.map((item) => [item.caseId, item.date, item.notes]),
  ];

  const categoryRows = [["Issue / Concern Category"], ...state.categories.map((category) => [category])];

  const files = {
    "[Content_Types].xml": contentTypesXml(),
    "_rels/.rels": rootRelsXml(),
    "docProps/app.xml": appPropsXml(),
    "docProps/core.xml": corePropsXml(),
    "xl/workbook.xml": workbookXml(),
    "xl/_rels/workbook.xml.rels": workbookRelsXml(),
    "xl/styles.xml": stylesXml(),
    "xl/worksheets/sheet1.xml": sheetXml(caseRows, new Set([1, 11])),
    "xl/worksheets/sheet2.xml": sheetXml(followRows, new Set([1])),
    "xl/worksheets/sheet3.xml": sheetXml(categoryRows, new Set()),
  };

  return createZip(files);
}

function sheetXml(rows, dateColumns) {
  const maxCols = Math.max(...rows.map((row) => row.length));
  const dimension = `A1:${columnName(maxCols - 1)}${rows.length}`;
  const rowsXml = rows.map((row, rowIndex) => {
    const cellsXml = row.map((value, columnIndex) => {
      if (value == null || value === "") return "";
      const ref = `${columnName(columnIndex)}${rowIndex + 1}`;
      if (rowIndex > 0 && dateColumns.has(columnIndex)) {
        const serial = dateToExcelSerial(String(value));
        return `<c r="${ref}" s="1"><v>${serial}</v></c>`;
      }
      const style = rowIndex === 0 ? ` s="2"` : "";
      return `<c r="${ref}" t="inlineStr"${style}><is><t>${escapeXml(String(value))}</t></is></c>`;
    }).join("");
    return `<row r="${rowIndex + 1}">${cellsXml}</row>`;
  }).join("");

  return xmlDeclaration(`
    <worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
      <dimension ref="${dimension}"/>
      <sheetViews><sheetView workbookViewId="0"><pane ySplit="1" topLeftCell="A2" activePane="bottomLeft" state="frozen"/></sheetView></sheetViews>
      <cols>
        <col min="1" max="1" width="14" customWidth="1"/>
        <col min="2" max="2" width="15" customWidth="1"/>
        <col min="3" max="5" width="20" customWidth="1"/>
        <col min="6" max="6" width="28" customWidth="1"/>
        <col min="7" max="7" width="22" customWidth="1"/>
        <col min="8" max="9" width="48" customWidth="1"/>
        <col min="10" max="12" width="16" customWidth="1"/>
        <col min="13" max="13" width="16" customWidth="1"/>
        <col min="14" max="14" width="28" customWidth="1"/>
        <col min="15" max="15" width="16" customWidth="1"/>
        <col min="16" max="16" width="48" customWidth="1"/>
      </cols>
      <sheetData>${rowsXml}</sheetData>
    </worksheet>
  `);
}

function contentTypesXml() {
  return xmlDeclaration(`
    <Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
      <Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
      <Default Extension="xml" ContentType="application/xml"/>
      <Override PartName="/docProps/app.xml" ContentType="application/vnd.openxmlformats-officedocument.extended-properties+xml"/>
      <Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/>
      <Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>
      <Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>
      <Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>
      <Override PartName="/xl/worksheets/sheet2.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>
      <Override PartName="/xl/worksheets/sheet3.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>
    </Types>
  `);
}

function rootRelsXml() {
  return xmlDeclaration(`
    <Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
      <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>
      <Relationship Id="rId2" Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties" Target="docProps/core.xml"/>
      <Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/extended-properties" Target="docProps/app.xml"/>
    </Relationships>
  `);
}

function workbookXml() {
  return xmlDeclaration(`
    <workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">
      <sheets>
        <sheet name="Cases" sheetId="1" r:id="rId1"/>
        <sheet name="Follow Ups" sheetId="2" r:id="rId2"/>
        <sheet name="Categories" sheetId="3" r:id="rId3"/>
      </sheets>
    </workbook>
  `);
}

function workbookRelsXml() {
  return xmlDeclaration(`
    <Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
      <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/>
      <Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet2.xml"/>
      <Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet3.xml"/>
      <Relationship Id="rId4" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>
    </Relationships>
  `);
}

function stylesXml() {
  return xmlDeclaration(`
    <styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
      <numFmts count="1"><numFmt numFmtId="164" formatCode="yyyy-mm-dd"/></numFmts>
      <fonts count="2">
        <font><sz val="11"/><color theme="1"/><name val="Calibri"/><family val="2"/></font>
        <font><b/><sz val="11"/><color rgb="FFFFFFFF"/><name val="Calibri"/><family val="2"/></font>
      </fonts>
      <fills count="3">
        <fill><patternFill patternType="none"/></fill>
        <fill><patternFill patternType="gray125"/></fill>
        <fill><patternFill patternType="solid"><fgColor rgb="FF24424A"/><bgColor indexed="64"/></patternFill></fill>
      </fills>
      <borders count="2">
        <border><left/><right/><top/><bottom/><diagonal/></border>
        <border><left/><right/><top/><bottom style="thin"><color rgb="FFD7DEE2"/></bottom><diagonal/></border>
      </borders>
      <cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>
      <cellXfs count="3">
        <xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/>
        <xf numFmtId="164" fontId="0" fillId="0" borderId="0" xfId="0" applyNumberFormat="1"/>
        <xf numFmtId="0" fontId="1" fillId="2" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1"/>
      </cellXfs>
      <cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles>
    </styleSheet>
  `);
}

function corePropsXml() {
  return xmlDeclaration(`
    <cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:dcterms="http://purl.org/dc/terms/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
      <dc:title>Case Management Cases</dc:title>
      <dc:creator>Case Management Dashboard</dc:creator>
      <dcterms:created xsi:type="dcterms:W3CDTF">${new Date().toISOString()}</dcterms:created>
      <dcterms:modified xsi:type="dcterms:W3CDTF">${new Date().toISOString()}</dcterms:modified>
    </cp:coreProperties>
  `);
}

function appPropsXml() {
  return xmlDeclaration(`
    <Properties xmlns="http://schemas.openxmlformats.org/officeDocument/2006/extended-properties" xmlns:vt="http://schemas.openxmlformats.org/officeDocument/2006/docPropsVTypes">
      <Application>Case Management Dashboard</Application>
    </Properties>
  `);
}

async function parseXlsx(buffer) {
  const entries = await readZipEntries(buffer);
  const decoder = new TextDecoder();
  const readXml = (name) => {
    const entry = entries.get(name);
    return entry ? decoder.decode(entry) : "";
  };

  const sharedStrings = parseSharedStrings(readXml("xl/sharedStrings.xml"));
  const workbookDoc = parseXml(readXml("xl/workbook.xml"));
  const rels = parseRelationships(readXml("xl/_rels/workbook.xml.rels"));
  const sheets = {};

  for (const sheet of elements(workbookDoc, "sheet")) {
    const name = sheet.getAttribute("name");
    const relId = sheet.getAttribute("r:id")
      || sheet.getAttributeNS("http://schemas.openxmlformats.org/officeDocument/2006/relationships", "id");
    const target = rels.get(relId);
    if (!name || !target) continue;

    const sheetPath = normalizeXlsxPath(target.startsWith("/") ? target.slice(1) : `xl/${target}`);
    const xml = readXml(sheetPath);
    if (xml) sheets[name] = parseWorksheet(xml, sharedStrings);
  }

  return { sheets };
}

function parseSharedStrings(xml) {
  if (!xml) return [];
  const doc = parseXml(xml);
  return elements(doc, "si").map((item) => elements(item, "t").map((text) => text.textContent || "").join(""));
}

function parseRelationships(xml) {
  const rels = new Map();
  if (!xml) return rels;
  const doc = parseXml(xml);
  for (const rel of elements(doc, "Relationship")) {
    rels.set(rel.getAttribute("Id"), rel.getAttribute("Target"));
  }
  return rels;
}

function parseWorksheet(xml, sharedStrings) {
  const doc = parseXml(xml);
  const rows = [];
  for (const rowElement of elements(doc, "row")) {
    const rowIndex = Number(rowElement.getAttribute("r") || rows.length + 1) - 1;
    const row = [];
    for (const cell of elements(rowElement, "c")) {
      const ref = cell.getAttribute("r") || "";
      const column = ref.match(/[A-Z]+/i)?.[0] || columnName(row.length);
      row[columnIndex(column)] = parseCellValue(cell, sharedStrings);
    }
    rows[rowIndex] = row;
  }
  return rows.filter(Boolean);
}

function parseCellValue(cell, sharedStrings) {
  const type = cell.getAttribute("t");
  if (type === "inlineStr") {
    return elements(cell, "t").map((item) => item.textContent || "").join("");
  }

  const raw = elements(cell, "v")[0]?.textContent || "";
  if (!raw) return "";
  if (type === "s") return sharedStrings[Number(raw)] || "";
  if (type === "b") return raw === "1";

  const numberValue = Number(raw);
  return Number.isFinite(numberValue) ? numberValue : raw;
}

async function readZipEntries(buffer) {
  const bytes = buffer instanceof Uint8Array ? buffer : new Uint8Array(buffer);
  const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
  const decoder = new TextDecoder();
  const eocd = findEndOfCentralDirectory(view);
  const entryCount = view.getUint16(eocd + 10, true);
  let pointer = view.getUint32(eocd + 16, true);
  const entries = new Map();

  for (let i = 0; i < entryCount; i += 1) {
    if (view.getUint32(pointer, true) !== 0x02014b50) {
      throw new Error("Invalid XLSX central directory.");
    }
    const method = view.getUint16(pointer + 10, true);
    const compressedSize = view.getUint32(pointer + 20, true);
    const fileNameLength = view.getUint16(pointer + 28, true);
    const extraLength = view.getUint16(pointer + 30, true);
    const commentLength = view.getUint16(pointer + 32, true);
    const localOffset = view.getUint32(pointer + 42, true);
    const nameStart = pointer + 46;
    const name = decoder.decode(bytes.slice(nameStart, nameStart + fileNameLength));

    const localNameLength = view.getUint16(localOffset + 26, true);
    const localExtraLength = view.getUint16(localOffset + 28, true);
    const dataStart = localOffset + 30 + localNameLength + localExtraLength;
    const data = bytes.slice(dataStart, dataStart + compressedSize);

    if (method === 0) {
      entries.set(name, data);
    } else if (method === 8) {
      entries.set(name, await inflateDeflate(data));
    }

    pointer += 46 + fileNameLength + extraLength + commentLength;
  }

  return entries;
}

function findEndOfCentralDirectory(view) {
  const min = Math.max(0, view.byteLength - 66000);
  for (let i = view.byteLength - 22; i >= min; i -= 1) {
    if (view.getUint32(i, true) === 0x06054b50) return i;
  }
  throw new Error("Invalid XLSX file.");
}

async function inflateDeflate(data) {
  if (typeof DecompressionStream === "undefined") {
    throw new Error("This browser cannot read compressed XLSX entries.");
  }

  let lastError;
  for (const format of ["deflate-raw", "deflate"]) {
    try {
      const stream = new Blob([data]).stream().pipeThrough(new DecompressionStream(format));
      return new Uint8Array(await new Response(stream).arrayBuffer());
    } catch (error) {
      lastError = error;
    }
  }
  throw lastError;
}

function createZip(files) {
  const encoder = new TextEncoder();
  const localParts = [];
  const centralParts = [];
  let offset = 0;

  for (const [name, content] of Object.entries(files)) {
    const nameBytes = encoder.encode(name);
    const dataBytes = typeof content === "string" ? encoder.encode(content) : content;
    const crc = crc32(dataBytes);
    const localHeader = new Uint8Array(30 + nameBytes.length);
    const localView = new DataView(localHeader.buffer);
    writeZipLocalHeader(localView, nameBytes.length, dataBytes.length, crc);
    localHeader.set(nameBytes, 30);
    localParts.push(localHeader, dataBytes);

    const centralHeader = new Uint8Array(46 + nameBytes.length);
    const centralView = new DataView(centralHeader.buffer);
    writeZipCentralHeader(centralView, nameBytes.length, dataBytes.length, crc, offset);
    centralHeader.set(nameBytes, 46);
    centralParts.push(centralHeader);

    offset += localHeader.length + dataBytes.length;
  }

  const centralOffset = offset;
  const centralSize = centralParts.reduce((sum, part) => sum + part.length, 0);
  const end = new Uint8Array(22);
  const endView = new DataView(end.buffer);
  endView.setUint32(0, 0x06054b50, true);
  endView.setUint16(8, Object.keys(files).length, true);
  endView.setUint16(10, Object.keys(files).length, true);
  endView.setUint32(12, centralSize, true);
  endView.setUint32(16, centralOffset, true);

  return concatUint8Arrays([...localParts, ...centralParts, end]);
}

function writeZipLocalHeader(view, nameLength, size, crc) {
  const { time, date } = zipDateTime();
  view.setUint32(0, 0x04034b50, true);
  view.setUint16(4, 20, true);
  view.setUint16(6, 0, true);
  view.setUint16(8, 0, true);
  view.setUint16(10, time, true);
  view.setUint16(12, date, true);
  view.setUint32(14, crc, true);
  view.setUint32(18, size, true);
  view.setUint32(22, size, true);
  view.setUint16(26, nameLength, true);
  view.setUint16(28, 0, true);
}

function writeZipCentralHeader(view, nameLength, size, crc, offset) {
  const { time, date } = zipDateTime();
  view.setUint32(0, 0x02014b50, true);
  view.setUint16(4, 20, true);
  view.setUint16(6, 20, true);
  view.setUint16(8, 0, true);
  view.setUint16(10, 0, true);
  view.setUint16(12, time, true);
  view.setUint16(14, date, true);
  view.setUint32(16, crc, true);
  view.setUint32(20, size, true);
  view.setUint32(24, size, true);
  view.setUint16(28, nameLength, true);
  view.setUint16(30, 0, true);
  view.setUint16(32, 0, true);
  view.setUint16(34, 0, true);
  view.setUint16(36, 0, true);
  view.setUint32(38, 0, true);
  view.setUint32(42, offset, true);
}

function zipDateTime() {
  const now = new Date();
  const time = (now.getHours() << 11) | (now.getMinutes() << 5) | Math.floor(now.getSeconds() / 2);
  const date = ((now.getFullYear() - 1980) << 9) | ((now.getMonth() + 1) << 5) | now.getDate();
  return { time, date };
}

let crcTable;
function crc32(bytes) {
  if (!crcTable) {
    crcTable = Array.from({ length: 256 }, (_, index) => {
      let c = index;
      for (let k = 0; k < 8; k += 1) {
        c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
      }
      return c >>> 0;
    });
  }

  let crc = 0xffffffff;
  for (const byte of bytes) {
    crc = crcTable[(crc ^ byte) & 0xff] ^ (crc >>> 8);
  }
  return (crc ^ 0xffffffff) >>> 0;
}

function concatUint8Arrays(parts) {
  const total = parts.reduce((sum, part) => sum + part.length, 0);
  const output = new Uint8Array(total);
  let offset = 0;
  for (const part of parts) {
    output.set(part, offset);
    offset += part.length;
  }
  return output;
}

function xmlDeclaration(body) {
  return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>${body.replace(/>\s+</g, "><").trim()}`;
}

function normalizeXlsxPath(path) {
  const parts = [];
  for (const part of path.split("/")) {
    if (!part || part === ".") continue;
    if (part === "..") parts.pop();
    else parts.push(part);
  }
  return parts.join("/");
}

function parseXml(xml) {
  if (!xml) throw new Error("Missing workbook XML.");
  const doc = new DOMParser().parseFromString(xml, "application/xml");
  const parserError = doc.getElementsByTagName("parsererror")[0];
  if (parserError) throw new Error(parserError.textContent || "XML parse error.");
  return doc;
}

function elements(root, localName) {
  const namespaced = Array.from(root.getElementsByTagNameNS("*", localName));
  if (namespaced.length) return namespaced;
  return Array.from(root.getElementsByTagName(localName));
}

function columnIndex(name) {
  return name.toUpperCase().split("").reduce((sum, char) => sum * 26 + char.charCodeAt(0) - 64, 0) - 1;
}

function columnName(index) {
  let name = "";
  let value = index + 1;
  while (value > 0) {
    const mod = (value - 1) % 26;
    name = String.fromCharCode(65 + mod) + name;
    value = Math.floor((value - mod) / 26);
  }
  return name;
}

function normalizeDate(value) {
  if (value == null || value === "") return "";
  if (typeof value === "number") return excelSerialToDate(value);

  const text = String(value).trim();
  if (!text) return "";
  if (/^\d{4}-\d{2}-\d{2}/.test(text)) return text.slice(0, 10);
  if (/^\d{1,2}\/\d{1,2}\/\d{4}$/.test(text)) {
    const [month, day, year] = text.split("/").map(Number);
    return toDateString(year, month, day);
  }

  const numeric = Number(text);
  if (Number.isFinite(numeric) && numeric > 25000 && numeric < 80000) {
    return excelSerialToDate(numeric);
  }

  const parsed = new Date(text);
  return Number.isNaN(parsed.getTime()) ? text : parsed.toISOString().slice(0, 10);
}

function excelSerialToDate(serial) {
  const utc = Date.UTC(1899, 11, 30) + Math.round(Number(serial)) * 86400000;
  return new Date(utc).toISOString().slice(0, 10);
}

function dateToExcelSerial(dateString) {
  const [year, month, day] = dateString.split("-").map(Number);
  const utc = Date.UTC(year, month - 1, day);
  return Math.round((utc - Date.UTC(1899, 11, 30)) / 86400000);
}

function todayString() {
  const today = new Date();
  return toDateString(today.getFullYear(), today.getMonth() + 1, today.getDate());
}

function toDateString(year, month, day) {
  return `${year}-${String(month).padStart(2, "0")}-${String(day).padStart(2, "0")}`;
}

function formatDate(value) {
  const date = normalizeDate(value);
  if (!date) return "Not set";
  const [year, month, day] = date.split("-");
  return `${month}/${day}/${year}`;
}

function formatDateSpan(values) {
  const dates = values.map(normalizeDate).filter(Boolean).sort();
  if (!dates.length) return "No dates";
  const first = formatDate(dates[0]);
  const last = formatDate(dates[dates.length - 1]);
  return first === last ? first : `${first} - ${last}`;
}

function formatDays(value) {
  const days = Math.max(0, Math.round(Number(value) || 0));
  return `${days} ${days === 1 ? "day" : "days"}`;
}

function daysBetween(start, end) {
  const startDate = new Date(`${start}T00:00:00Z`);
  const endDate = new Date(`${end}T00:00:00Z`);
  return Math.round((endDate - startDate) / 86400000);
}

function uniqueValues(values) {
  return [...new Set(values.map((value) => String(value || "").trim()).filter(Boolean))]
    .sort((a, b) => a.localeCompare(b));
}

function maskName(value) {
  const text = String(value || "").trim();
  if (!state.privacyMode || !text || ["Not specified", "Not applicable", "N/A"].includes(text)) {
    return text || "Not specified";
  }
  return text.split(/\s+/).map((part) => `${part[0] || ""}.`).join(" ");
}

function maskId(value) {
  const text = String(value || "").trim();
  if (!state.privacyMode || text.length < 3) return text;
  return `${"*".repeat(Math.max(0, text.length - 2))}${text.slice(-2)}`;
}

function maskSensitiveText(value) {
  const text = String(value || "").trim();
  if (!state.privacyMode || !text) return text;
  let masked = text;
  for (const name of uniqueValues([
    ...state.cases.map((item) => item.employeeName),
    ...state.cases.map((item) => item.manager),
    ...state.cases.map((item) => item.accusedEmployee),
  ])) {
    if (["Not specified", "Not applicable", "N/A"].includes(name)) continue;
    masked = masked.replaceAll(name, maskName(name));
  }
  return masked;
}

function riskClass(value) {
  const risk = String(value || "").toLowerCase();
  if (risk === "high") return "high";
  if (risk === "low") return "low";
  return "moderate";
}

function safeHttpUrl(value) {
  try {
    const url = new URL(value);
    return url.protocol === "http:" || url.protocol === "https:" ? url.href : "";
  } catch {
    return "";
  }
}

function base64ToArrayBuffer(base64) {
  const binary = atob(base64);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i += 1) {
    bytes[i] = binary.charCodeAt(i);
  }
  return bytes.buffer;
}

function escapeHtml(value) {
  return String(value ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}

function escapeAttribute(value) {
  return escapeHtml(value).replace(/`/g, "&#096;");
}

function escapeXml(value) {
  return String(value ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&apos;");
}
